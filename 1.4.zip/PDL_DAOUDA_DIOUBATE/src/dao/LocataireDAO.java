package dao;
import java.sql.*;
import java.util.ArrayList;
import model.Locataire;

/**
 * Classe d'acces aux donnees contenues dans la table Locataire
 * 
 * @author Ilyas DAOUDA + Nicolas DIOUBATE
 * @version 1.0
 * */
public class LocataireDAO extends ConnectionDAO {
	/**
	 * Constructeur de la classe
	 * 
	 */
	public LocataireDAO() {
		super();
	}

	/**
	 * Permet d'ajouter un Locataire dans la table Locataire
	 * Le mode est auto-commit par defaut : chaque insertion est validee
	 * 
	 * @param Locataire le Locataire a ajouter
	 * @return retourne le nombre de lignes ajoutees dans la table
	 */
	public int addLocataire(Locataire Locataire) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans l'insertion.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("INSERT INTO Locataire(idLocataire, nom, prenom, adresse, email, telephone, societe, raisonSociale, idBail, idBien) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			ps.setInt(1, Locataire.getIdLocataire());
			ps.setString(2, Locataire.getNom());
			ps.setString(3, Locataire.getPrenom());
			ps.setString(4, Locataire.getAdresse());
			ps.setString(5, Locataire.getEmail());
			ps.setString(6, Locataire.getSociete()); // On a mis dans les tables 
			ps.setString(7, Locataire.getSociete());
			ps.setString(8, Locataire.getRaisonSociale());
			ps.setInt(9, Locataire.getIdBail());
			ps.setInt(10, Locataire.getIdBien());







			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			if (e.getMessage().contains("ORA-00001"))
				System.out.println("Cet identifiant de Locataire existe déjà. Ajout impossible !");
			else
				e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try { 
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	/**
	 * Permet de modifier un Locataire dans la table Locataire
	 * Le mode est auto-commit par defaut : chaque modification est validee
	 * 
	 * @param Locataire le Locataire a modifier
	 * @return retourne le nombre de lignes modifiees dans la table
	 */
	public int updateLocataire(Locataire Locataire) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans la modification.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("UPDATE Locataire set nom = ?, prenom = ?, adresse = ?, email = ?, telephone = ?, societe = ?, raiosnSociale = ?, idBail = ?, idBien =?, WHERE idLocataire = ?");
			ps.setString(1, Locataire.getNom());
			ps.setString(2, Locataire.getPrenom());
			ps.setString(3, Locataire.getAdresse());
			ps.setInt(4, Locataire.getIdLocataire());
			ps.setString(5, Locataire.getEmail());
			ps.setString(6, Locataire.getNumero());
			ps.setString(7, Locataire.getSociete());
			ps.setString(8, Locataire.getRaisonSociale());
			ps.setInt(9, Locataire.getIdBail());
			ps.setInt(10, Locataire.getIdBien());

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	/**
	 * Permet de supprimer un Locataire par idLocataire dans la table Locataire
	 * Le mode est auto-commit par defaut : chaque suppression est validee
	 * 
	 * @param idLocataire l'identifiant du Locataire à supprimer
	 * @return retourne le nombre de lignes supprimees dans la table
	 */
	public int deleteLocataire(int idLocataire) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, le ? represente la valeur de l'identifiant
			// a communiquer dans la suppression.
			// le getter permet de recuperer la valeur de l'identifiant du Locataire
			ps = con.prepareStatement("DELETE FROM Locataire WHERE idLocataire = ?");
			ps.setInt(1, idLocataire);

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}


	/**
	 * Permet de recuperer un Locataire a partir de son identifiant
	 * 
	 * @param idLocataire l'identifiant du fournisseur a recuperer
	 * @return le Locataire trouve; null si aucun Locataire ne correspond a cet identifiant
	 */
	public Locataire getLocataire(int idLocataire) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Locataire returnValue = null;

		// connexion a la base de donnees
		try {

			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM Locataire WHERE idLocataire = ?");
			ps.setInt(1, idLocataire);

			// on execute la requete
			// rs contient un pointeur situe juste avant la premiere ligne retournee
			rs = ps.executeQuery();
			// passe a la premiere (et unique) ligne retournee
			if (rs.next()) {
				returnValue = new Locataire(rs.getInt("idLocataire"),
									       rs.getString("nom"),
									       rs.getString("prenom"),
									       rs.getString("adresse"),
									       rs.getString("email"),
									       rs.getString("telephone"),
									       rs.getString("societe"),
									       rs.getString("raisonSociale"),
									       rs.getInt("idBail"),
									       rs.getInt("idBien"));
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du ResultSet, du PreparedStatement et de la Connexion
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	/**
	 * Permet de recuperer tous les Locataires stockes dans la table Locataire
	 * 
	 * @return une ArrayList de Locataire
	 */
	public ArrayList<Locataire> getList() {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Locataire> returnValue = new ArrayList<Locataire>();

		// connexion a la base de donnees
		try {
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM Locataire ORDER BY idLocataire");

			// on execute la requete
			rs = ps.executeQuery();
			// on parcourt les lignes du resultat
			while (rs.next()) {
				returnValue.add(new Locataire(rs.getInt("idLocataire"),
					       rs.getString("nom"),
					       rs.getString("prenom"),
					       rs.getString("adresse"),
					       rs.getString("email"),
					       rs.getString("telephone"),
					       rs.getString("societe"),
					       rs.getString("raisonSociale"),
					       rs.getInt("idBail"),
					       rs.getInt("idBien")));
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du rs, du preparedStatement et de la connexion
			try {
				if (rs != null)
					rs.close();
			} catch (Exception ignore) {
			}
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	/**
	 * ATTENTION : Cette méthode n'a pas vocation à être executée lors d'une utilisation normale du programme !
	 * Elle existe uniquement pour TESTER les méthodes écrites au-dessus !
	 * 
	 * @param args non utilisés
	 * @throws SQLException si une erreur se produit lors de la communication avec la BDD
	 */
	public static void main(String[] args) throws SQLException {
		int returnValue;
		LocataireDAO LocataireDAO = new LocataireDAO();
		// Ce test va utiliser directement votre BDD, on essaie d'éviter les collisions avec vos données en prenant de grands ID
		int[] ids = {424242, 424243, 424244};
		// test du constructeur
		Locataire s1 = new Locataire(ids[0], "Ilyas", "Daouda", "Volta");
		Locataire s2 = new Locataire(ids[1], "Nicolas", "Dioubate", "Turing");
		Locataire s3 = new Locataire(ids[2], "Chloe", "Cabot", "Charliat");
		// test de la methode add
		returnValue = LocataireDAO.addLocataire(s1);
		System.out.println(returnValue + " Locataire ajoute");
		returnValue = LocataireDAO.addLocataire(s2);
		System.out.println(returnValue + " Locataire ajoute");
		returnValue = LocataireDAO.addLocataire(s3);
		System.out.println(returnValue + " Locataire ajoute");
		System.out.println();
		
		// test de la methode get
		Locataire sg = LocataireDAO.getLocataire(1);
		// appel implicite de la methode toString de la classe Object (a eviter)
		System.out.println(sg);
		System.out.println();
		
		// test de la methode getList
		ArrayList<Locataire> list = LocataireDAO.getList();
		for (Locataire s : list) {
			// appel explicite de la methode toString de la classe Object (a privilegier)
			System.out.println(s.toString());
		}
		System.out.println();
		// test de la methode delete
		// On supprime les 3 Locataires qu'on a créé
		returnValue = 0;
		for (int id : ids) {
//			returnValue = LocataireDAO.deleteLocataire(id);
			System.out.println(returnValue + " fournisseur supprime");
		}
		
		System.out.println();
	}
}