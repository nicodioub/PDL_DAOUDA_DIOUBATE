
import gui.*;

public class Test {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    	//Accueil Window1 = new Accueil("Logiciel de gestion DD",1400,750);
		//tWindow.dispose();

    	//MainInterface Window2 = new MainInterface("Logiciel de gestion DD",1400,800);

    	AddProperty Window3 = new AddProperty("Logiciel de gestion DD",1400,800);		
		
		//AjoutGarant Window4 = new AjoutGarant("Logiciel de gestion DD", 1400,800);
		
		//AjoutLocataire Window5 = new AjoutLocataire("Logiciel de gestion DD", 1400,800);
		
		
    	//MainInterfaceLocataire Window6 = new MainInterfaceLocataire("Logiciel de gestion DD", 1400,800);


		}

}
 