// Faire le DAO de Locataire avant de pouvoir continuer ca 

package gui;

import dao.LocataireDAO;
import javax.swing.ImageIcon;
import java.awt.Image;
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import model.Locataire;

import java.awt.Color;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Container;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.JTable;

public class AjoutLocataire extends JFrame {
	
	   private JTextField idLocataire;
	    private JTextField nomLocataire;
	    private JTextField prenomLocataire;
	    private JTextField adresse;
	    private JTextField email;
	    private JTextField telephone;
	    private JTextField societe ;
	    private JTextField raisonSociale;
	    private JTextField idBail;
	    private JTextField idBien;
	    
	    private JPanel jlBackground;
	    private JButton enregistrer;
	    private boolean enregistrerButton = false;

		private Container container;

	    
	

public AjoutLocataire (String title, int width, int height  ) {
		
		this.setTitle(title);
		this.setSize(width, height);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		int buttonWidth = 100; // Largeur du JButton
       int buttonHeight = 30; // Hauteur du JButton
       
       
       idLocataire = new JTextField("id Locataire");
       nomLocataire = new JTextField("nom Locataire");
       prenomLocataire = new JTextField("Prenom Locataire"); 
       adresse = new JTextField("Adresse");
       email = new JTextField("Email");
       telephone = new JTextField("Telephone");
       societe = new JTextField("Societe");
       raisonSociale = new JTextField("Raison sociale ");
       idBail = new JTextField("id Bail");
       idBien = new JTextField("idBien");





       
       
       jlBackground = new JPanel();
		this.setContentPane(jlBackground);
		enregistrer = new JButton("Enregistrer");
		container = this.getContentPane();
		
		
		
		container.setLayout(null); // Définir le layout sur null pour permettre le positionnement absolu
       idLocataire.setBounds(100,50,150,30);
       nomLocataire.setBounds(100,90,150,30);
       prenomLocataire.setBounds(100,130,150,30);
       adresse.setBounds(100,170,150,30);
       email.setBounds(100,210,150,30);
       telephone.setBounds(100,250,150,30);
       societe.setBounds(100,290,150,30);
       raisonSociale.setBounds(100,330,150,30);
       idBail.setBounds(100,370,150,30);
       idBien.setBounds(100,410,150,30);






       enregistrer.setBounds(300, 650, 150, 30);

       
       container.add(idLocataire);
       container.add(nomLocataire);
       container.add(prenomLocataire);
       container.add(adresse);
       container.add(email);
       container.add(telephone);
       container.add(societe);
       container.add(raisonSociale);
       container.add(idBail);
       container.add(idBien);
       container.add(enregistrer);
       
		//jlBackground.setBackground(Color.BLACK);
		
       this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		
		
		enregistrer.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	String idLocataireText = idLocataire.getText();
		    	int idLocataireInt = Integer.parseInt(idLocataireText);
		    	
		    	String nomLocataireText = nomLocataire.getText();
		    	String prenomLocataireText = prenomLocataire.getText();
		    	String adresseText = adresse.getText();
		    	String emailText = email.getText();
		    	String telephoneText = telephone.getText();
		    	String societeText = societe.getText();
		    	String raisonSocialeText = raisonSociale.getText();
		    	int idBailInt = Integer.parseInt(idBail.getText());
		    	int idBienInt = Integer.parseInt(idBien.getText());

		    	System.out.println(idLocataireText);
		    	
		    	Locataire locataire1 = new Locataire(idLocataireInt, nomLocataireText,prenomLocataireText, adresseText, emailText,telephoneText,societeText,raisonSocialeText,idBailInt,idBienInt);
		    	
		    	LocataireDAO LocataireDAO = new LocataireDAO();
		    	
		    	LocataireDAO.addLocataire(locataire1);
		        
		
		    }
		}
		
				);
		

}
public boolean enregistrerClicked() {
	return enregistrerButton;
}
		    }
		


