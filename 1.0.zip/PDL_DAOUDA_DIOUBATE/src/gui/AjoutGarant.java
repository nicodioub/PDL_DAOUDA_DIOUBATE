package gui;

import javax.swing.ImageIcon;
import java.awt.Image;
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Container;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.JTable;



public class AjoutGarant extends JFrame{

	    private JTextField idGarant;
	    private JTextField nomGarant;
	    private JTextField prenomGarant;
	    private JTextField adresse;
	    private JPanel jlBackground;
	    private JButton enregistrer;
		private Container container;

	    
	

public AjoutGarant (String title, int width, int height  ) {
		
		this.setTitle(title);
		this.setSize(width, height);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		int buttonWidth = 100; // Largeur du JButton
        int buttonHeight = 30; // Hauteur du JButton
        
        
        idGarant = new JTextField("id Garant");
        nomGarant = new JTextField("nom Garant");
        prenomGarant = new JTextField("Prenom Garant"); // mettre quelque chose à choic unique (oui/non)
        adresse = new JTextField("Adresse");
		
        
        
        jlBackground = new JPanel();
		this.setContentPane(jlBackground);
		enregistrer = new JButton("Enregistrer");
		container = this.getContentPane();
		
		
		
		container.setLayout(null); // Définir le layout sur null pour permettre le positionnement absolu
        idGarant.setBounds(100,50,150,30);
        nomGarant.setBounds(100,90,150,30);
        prenomGarant.setBounds(100,130,150,30);
        adresse.setBounds(100,170,150,30);
        enregistrer.setBounds(300, 650, 150, 30);

        
        container.add(idGarant);
        container.add(nomGarant);
        container.add(prenomGarant);
        container.add(adresse);
        container.add(enregistrer);
        
		//jlBackground.setBackground(Color.BLACK);
		
        this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		enregistrer.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	String idGarantText = idGarant.getText();
		    	String nomGarantText = nomGarant.getText();
		    	String prenomGarantText = prenomGarant.getText();
		    	String adresseText = adresse.getText();
		    	
		    	System.out.println(idGarantText);
		        
		
		    }
		});

}
		    }
		







