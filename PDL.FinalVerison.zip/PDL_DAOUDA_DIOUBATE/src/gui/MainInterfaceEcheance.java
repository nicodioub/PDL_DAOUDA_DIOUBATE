package gui;
import  dao.*;
import javax.swing.*;
import java.awt.*;
import model.*;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

public class MainInterfaceEcheance extends JFrame {
	
	private JPanel jlBackground;
	private JLabel jlColor;
	private JButton ajoutLocataire;
	private JButton Bien;
	private JButton Locataire;
	private JButton Bail;
	private JButton ajoutGarant;
	private JButton Bailleur;
	private JButton retour;
	private JButton appelLoyer;
	private JButton modifier;
	private JButton supprimer;
	private JButton Echeance;



	private Container container;

	private AddProperty window;
	
	private boolean addPropertyButton = false;


	public MainInterfaceEcheance (String title, int width, int height  ) {
		
		this.setTitle(title);
		this.setSize(width, height);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		int buttonWidth = 100; // Largeur du JButton
        int buttonHeight = 30; // Hauteur du JButton
        
        EcheanceDAO echeanceInfo = new EcheanceDAO();

        
        JFrame frame = new JFrame("Supprimer une valeur de la base de données");

		supprimer = new JButton("Supprimer");
		modifier = new JButton("Modifier");
		jlBackground = new JPanel();
		this.setContentPane(jlBackground);
		Bien = new JButton("Bien");
		Bailleur = new JButton("Bailleur");
		retour = new JButton("Retour");
		Locataire = new JButton("Locataire");
		ajoutLocataire= new JButton("+ Créer une échéance");
		Bail = new JButton("Bail");
		Echeance = new JButton("Echeance");

		ajoutGarant = new JButton("+ Ajout Garant");
		appelLoyer = new JButton("Emettre un appel à loyer");
		container = this.getContentPane();
		

		String[] columnNames = {"id", "Loyer","Statut","Historique","Retard"};
		
		List<Object[]> dataList = new ArrayList<>();

		for (int i = 1; i < echeanceInfo.getMaxIdEcheance(); i++) {
		    dataList.add(new Object[] {
		        echeanceInfo.getEcheanceId(i),
		        echeanceInfo.getEcheanceLoyer(i),
		        echeanceInfo.getEcheanceStatut(i),
		        echeanceInfo.getEcheanceHistorique(i),
		        echeanceInfo.getEcheanceRetard(i)
		    });
		}

		// Convertir la liste en un tableau à deux dimensions
		Object[][] data = new Object[dataList.size()][];
		for (int i = 0; i < dataList.size(); i++) {
		    data[i] = dataList.get(i);
		}
		
		
		JTable table = new JTable(data, columnNames);
		
	    //table.setBackground(Color.BLACK); // Change to desired color

		
		JScrollPane scrollPane = new JScrollPane(table);
        
		 //scrollPane.getViewport().setBackground(Color.BLACK); // Change to desired color

	        
		container.setLayout(null); // Définir le layout sur null pour permettre le positionnement absolu
        
		scrollPane.setBounds(10, 100, 1390, 600); // Adjust bounds as needed
        ajoutLocataire.setBounds(1150, 50, 160, buttonHeight);
	    Bien.setBounds(500,50  , 100, 30);
	    Locataire.setBounds(600,50,100,30);
	    Bail.setBounds(700,50,100,30);
	    ajoutGarant.setBounds(1000,50,150,buttonHeight);
	    Bailleur.setBounds(800,50,100,30);
	    retour.setBounds(50,710,100,30);
	    modifier.setBounds(50,650,100,30);
	    supprimer.setBounds(200,650,100,30);
	    Echeance.setBounds(400,50,100,30);

	    appelLoyer.setBounds(10,50,200,30);

	    
        container.add(ajoutLocataire);
        container.add(Bien);
        container.add(Locataire);
        container.add(Bail);
        container.add(modifier);
        container.add(supprimer);
        //container.add(ajoutGarant);
        container.add(Bailleur);
        container.add(appelLoyer);
        container.add(Echeance);

        
        container.add(scrollPane);
       // container.add(retour);
		jlBackground.setBackground(Color.BLACK);

		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		
		ajoutLocataire.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	addPropertyButton = true;
		    	CreationEcheance Window5 = new CreationEcheance("Logiciel de gestion DD", 1400,800);
		    	Window5.setVisible(true);
		        dispose(); // Ferme l'interface 2
		    }
		});
		
		appelLoyer.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        addPropertyButton = true;

		        // Afficher une boîte de dialogue pour choisir un locataire
		        String idLocataire = JOptionPane.showInputDialog(null, "Veuillez entrer l'ID du locataire :");

		        // Vérifier si l'utilisateur a entré quelque chose
		        if (idLocataire != null && !idLocataire.isEmpty()) {
		            int idLocataireInt = Integer.parseInt(idLocataire);

		            // Afficher une boîte de dialogue pour entrer la date de l'échéance
		            String dateEcheanceStr = JOptionPane.showInputDialog(null, "Veuillez entrer le jour de l'échéance (1-31) :");

		            // Vérifier si l'utilisateur a entré quelque chose
		            if (dateEcheanceStr != null && !dateEcheanceStr.isEmpty()) {
		                int dateEcheance = Integer.parseInt(dateEcheanceStr);

		                // Afficher un menu avec des boutons pour choisir l'action
		                String[] actions = {"Ajouter un loyer à payer", "Régler le loyer", "Ajouter une pénalité"};
		                String action = (String) JOptionPane.showInputDialog(null, "Choisissez l'action à effectuer :",
		                        "Gestion des loyers", JOptionPane.QUESTION_MESSAGE, null, actions, actions[0]);

		                if (action != null && !action.isEmpty()) {
		                    switch (action) {
		                        case "Ajouter un loyer à payer":
		                            // Afficher une boîte de dialogue pour entrer le montant du loyer
		                            String montantLoyerStr = JOptionPane.showInputDialog(null, "Entrez le montant du loyer :");
		                            if (montantLoyerStr != null && !montantLoyerStr.isEmpty()) {
		                                float montantLoyer = Float.parseFloat(montantLoyerStr);
		                                // Ajouter l'échéance de loyer dans la base de données
		                                echeanceInfo.ajoutLoyer(idLocataireInt, dateEcheance, montantLoyer);
		                                JOptionPane.showMessageDialog(null, "L'échéance de loyer a été ajoutée avec succès.", "Succès", JOptionPane.INFORMATION_MESSAGE);
		                            } else {
		                                JOptionPane.showMessageDialog(null, "Ajout annulé.", "Information", JOptionPane.INFORMATION_MESSAGE);
		                            }
		                            break;

		                        case "Régler le loyer":
		                            // Afficher une boîte de dialogue pour entrer le montant payé
		                            String montantPayeStr = JOptionPane.showInputDialog(null, "Entrez le montant payé :");
		                            if (montantPayeStr != null && !montantPayeStr.isEmpty()) {
		                                float montantPaye = Float.parseFloat(montantPayeStr);
		                                // Régler le loyer pour l'échéance donnée
		                                echeanceInfo.reglerLoyer(idLocataireInt, dateEcheance, montantPaye);
		                                JOptionPane.showMessageDialog(null, "Le loyer a été réglé avec succès.", "Succès", JOptionPane.INFORMATION_MESSAGE);
		                            } else {
		                                JOptionPane.showMessageDialog(null, "Règlement annulé.", "Information", JOptionPane.INFORMATION_MESSAGE);
		                            }
		                            break;

		                       
		                    }

		                    // Actualiser l'interface principale
		                    MainInterfaceEcheance window1 = new MainInterfaceEcheance("Logiciel de gestion DD", 1400, 800);
		                    window1.setVisible(true);
		                    dispose(); // Ferme l'interface actuelle
		                } else {
		                    JOptionPane.showMessageDialog(null, "Action annulée.", "Information", JOptionPane.INFORMATION_MESSAGE);
		                }
		            } else {
		                JOptionPane.showMessageDialog(null, "Date d'échéance non saisie. Action annulée.", "Information", JOptionPane.INFORMATION_MESSAGE);
		            }
		        } else {
		            JOptionPane.showMessageDialog(null, "ID de locataire non saisi. Action annulée.", "Information", JOptionPane.INFORMATION_MESSAGE);
		        }
		    }
		});



		
		Bien.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	MainInterface Window1 = new MainInterface("Logiciel de gestion DD", 1400,800);
			    	Window1.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
			
		});
		
		Bail.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	MainInterfaceBail Window7 = new MainInterfaceBail("Logiciel de gestion DD", 1400,800);
			    	Window7.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
			
		});
		
		Bailleur.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	MainInterfaceBailleur Window10 = new MainInterfaceBailleur("Logiciel de gestion DD", 1400,800);
			    	Window10.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
			
		});
		
		ajoutGarant.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	AjoutGarant Window4 = new AjoutGarant("Logiciel de gestion DD", 1400,800);
			    	Window4.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
			
		});
		
		retour.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	AjoutGarant Window4 = new AjoutGarant("Logiciel de gestion DD", 1400,800);
			    	Window4.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
			
		});
		Locataire.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	MainInterfaceLocataire Window6 = new MainInterfaceLocataire("Logiciel de gestion DD", 1400,800);
			    	Window6.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
			
		});
		supprimer.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	// Afficher une boîte de dialogue pour entrer l'ID de la valeur à supprimer
	                String id = JOptionPane.showInputDialog(frame, "Entrez l'ID de la valeur à supprimer:");

	                // Vérifier si l'utilisateur a entré quelque chose
	                if (id != null && !id.isEmpty()) {
	                    // Supprimer la valeur de la base de données (action factice ici)
	                    // Remplacez cette étape par la suppression réelle de la valeur dans votre base de données
	                    // Exemple : database.deleteValue(id);

	                    // Afficher un message indiquant que la valeur a été supprimée avec succès
	                	int idInt = Integer.parseInt(id);
	                	JOptionPane.showMessageDialog(frame, "La valeur avec l'ID " + id + " a été supprimée de votre base de données.", "Suppression réussie", JOptionPane.INFORMATION_MESSAGE);
	                	echeanceInfo.deleteBien(idInt);
	                	MainInterface Window1 = new MainInterface("Logiciel de gestion DD", 1400,800);
				    	Window1.setVisible(true);
				        dispose(); // Ferme l'interface 2
	                } else {
	                    // Afficher un message si l'utilisateur a annulé l'entrée ou n'a rien entré
	                    JOptionPane.showMessageDialog(frame, "Suppression annulée.", "Information", JOptionPane.INFORMATION_MESSAGE);
	                }
			    	
			    }
			
		});
		
		modifier.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        addPropertyButton = true;
		        // Afficher une boîte de dialogue pour entrer l'ID de la valeur à modifier
		        String id = JOptionPane.showInputDialog(null, "Quel bien voulez-vous modifier ?\nSaisissez son ID :");

		        // Vérifier si l'utilisateur a entré quelque chose
		        if (id != null && !id.isEmpty()) {

		            int idInt = Integer.parseInt(id);

		            String dateEcheance = "Date d'Échéance";
		            String statutPaiement = "Statut de Paiement";
		            String historique = "Historique";
		            String montantLoyer = "Montant du Loyer";
		            String montantRetard = "Montant du Retard";
		            String penaliteRetard = "Pénalité de Retard";
		            String commentaire = "Commentaire";
		            String idLocataire = "ID du Locataire";
		            String idBail = "ID du Bail";

		            // Afficher un menu avec des boutons radio pour choisir quel composant modifier
		            String[] components = {
		                dateEcheance,
		                statutPaiement,
		                historique,
		                montantLoyer,
		                montantRetard,
		                penaliteRetard,
		                commentaire,
		                idLocataire,
		                idBail,
		            };

		            String component = (String) JOptionPane.showInputDialog(null, "Choisissez le composant à modifier :",
		                    "Modifier Composant", JOptionPane.QUESTION_MESSAGE, null, components, components[0]);

		            if (component != null && !component.isEmpty()) {
		                // Afficher une boîte de dialogue pour entrer la nouvelle valeur
		                String newValue = JOptionPane.showInputDialog(null, "Entrez la nouvelle valeur pour " + component + " :");

		                // Vérifier si l'utilisateur a entré quelque chose
		                if (newValue != null && !newValue.isEmpty()) {

		                    if (component.equals(dateEcheance)) {
		                        int newValueInt = Integer.parseInt(newValue);

		                        echeanceInfo.updateDateEcheance(idInt, newValueInt);
		                    } else if (component.equals(statutPaiement)) {
		                        echeanceInfo.updateStatutPaiement(idInt, newValue);
		                    } else if (component.equals(historique)) {
		                        int newValueInt = Integer.parseInt(newValue);
		                        echeanceInfo.updateHistorique(idInt, newValueInt);
		                    } else if (component.equals(montantLoyer)) {
		                        float newValueFloat = Float.parseFloat(newValue);
		                        echeanceInfo.updateMontantLoyer(idInt, newValueFloat);
		                    } else if (component.equals(montantRetard)) {
		                        float newValueFloat = Float.parseFloat(newValue);
		                        echeanceInfo.updateMontantRetard(idInt, newValueFloat);
		                    } else if (component.equals(penaliteRetard)) {
		                        float newValueFloat = Float.parseFloat(newValue);
		                        echeanceInfo.updatePenaliteRetard(idInt, newValueFloat);
		                    } else if (component.equals(commentaire)) {
		                        echeanceInfo.updateCommentaire(idInt, newValue);
		                    } else if (component.equals(idLocataire)) {
		                        int newValueInt = Integer.parseInt(newValue);
		                        echeanceInfo.updateIdLocataire(idInt, newValueInt);
		                    } else if (component.equals(idBail)) {
		                        int newValueInt = Integer.parseInt(newValue);
		                        echeanceInfo.updateIdBail(idInt, newValueInt);
		                    }

		                    // Afficher un message indiquant que la valeur a été modifiée avec succès
		                    JOptionPane.showMessageDialog(null, "La valeur de " + component + " pour le bien avec l'ID " + id +
		                            " a été modifiée en " + newValue + ".", "Modification réussie", JOptionPane.INFORMATION_MESSAGE);

		                    // Appel à la méthode de modification de votre objet
		                    // updateValue(idInt, component, newValue);

		                    // Actualiser l'interface principale
		                    MainInterfaceEcheance window1 = new MainInterfaceEcheance("Logiciel de gestion DD", 1400, 800);
		                    window1.setVisible(true);
		                    dispose(); // Ferme l'interface actuelle
		                } else {
		                    // Afficher un message si l'utilisateur a annulé l'entrée ou n'a rien entré
		                    JOptionPane.showMessageDialog(null, "Modification annulée.", "Information", JOptionPane.INFORMATION_MESSAGE);
		                }
		            } else {
		                // Afficher un message si l'utilisateur a annulé la sélection du composant
		                JOptionPane.showMessageDialog(null, "Modification annulée.", "Information", JOptionPane.INFORMATION_MESSAGE);
		            }
		        } else {
		            // Afficher un message si l'utilisateur a annulé l'entrée ou n'a rien entré
		            JOptionPane.showMessageDialog(null, "Modification annulée.", "Information", JOptionPane.INFORMATION_MESSAGE);
		        }
		    }
		});

		
		//a faire 
		
		
		

	}
	
	/**
	 * Permet de verifier si l'utilisateur a clique sur 'Ajouter bail'
	 * 
	 * @return l'attribut addPropertyButton
	 */
	public boolean addPropertyClicked() {
		return addPropertyButton;
	}
	
	

}
