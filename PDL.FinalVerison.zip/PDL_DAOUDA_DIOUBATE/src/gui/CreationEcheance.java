// Faire le DAO de Bailleur avant de pouvoir continuer ca 

package gui;

import javax.swing.*;
import dao.*;
import model.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;


public class CreationEcheance extends JFrame {
	
	private JPanel jlBackground;
    private JButton enregistrer;
    private boolean enregistrerButton = false;
	private Container container;
	
	
		
    // Zone de texte pour le nom du Bailleur
    private JTextField idBail = new JTextField("id du bail");
    
    // Zone de texte pour le prénom du Bailleur
    private JTextField idLocataire = new JTextField("id du locataire");
    
    // Zone de texte pour l'statutPaiement du Bailleur
    private JTextField statutPaiement = new JTextField("statut du paiement"); // menu si tu as le temps 
    
    // Zone de texte pour le mail du Bailleur
    private JTextField dateEcheance = new JTextField("Date d'échénace ");
    
    // Zone de texte pour le numéro du Bailleur
    private JTextField historique = new JTextField("Historique");
    
    // Zone de texte pour la raison sociale du Bailleur
    private JTextField montantLoyer = new JTextField("Montant du loyer");
    
    // Zone de texte pour l'id du Bien associé au Bailleur
    private JTextField montantRetard = new JTextField("Montant à payer");
    
    private JTextField penalite = new JTextField("Pénalité de retard");

    private JTextField commentaire = new JTextField("Commentaire");

    
    private JButton retour = new JButton("Retour");
	   
	    
    // Création du menu pour indiquer si le bien est une société ou pas
   	String[] choixMenuSociete = {"Société", "Oui", "Non"};
   	private String choixSocieteOuNon;
    private JComboBox<String> menuSociete = new JComboBox<>(choixMenuSociete);
    
    
	private boolean addPropertyButton = false;

	public CreationEcheance (String title, int width, int height  ) {
			
		this.setTitle(title);
		this.setSize(width, height);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	       
	    jlBackground = new JPanel();
		this.setContentPane(jlBackground);
		enregistrer = new JButton("Enregistrer");
		retour = new JButton("Retour");
		container = this.getContentPane();
		container.setLayout(null); // Définir le layout sur null pour permettre le positionnement absolu
		retour = new JButton("Retour");
		retour.setBackground(Color.RED);
		
		idBail.setBounds(100, 90, 150, 30);
		idLocataire.setBounds(100, 130, 150, 30);
		montantLoyer.setBounds(100, 170, 150, 30);
		dateEcheance.setBounds(100, 210, 150, 30);
		statutPaiement.setBounds(100, 250, 150, 30);
		montantRetard.setBounds(100, 290, 150, 30);
		penalite.setBounds(100, 330, 150, 30);
		historique.setBounds(100, 370, 150, 30);
		commentaire.setBounds(100, 410, 150, 30);



	    retour.setBounds(300,690,100,30);
	
	    enregistrer.setBounds(300, 650, 150, 30);
	    
	    
	    // Définir un rendu personnalisé pour le menu déroulant pour l'indicateur societe
	    
	
	    // Ajout d'un écouteur d'événements pour détecter la sélection d'un élément
	   
	    
	    // Ajout d'un écouteur de focus au champ de texte du nom du Bailleur
	    idBail.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (idBail.getText().equals("Nom du Bailleur")) {
	            	idBail.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (idBail.getText().isEmpty()) {
	            	idBail.setText("Nom du Bailleur");
	            }
	        }
	    });
	    
	    // Ajout d'un écouteur de focus au champ de texte du prénom du Bailleur
	    idLocataire.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (idLocataire.getText().equals("Prénom du Bailleur")) {
	            	idLocataire.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (idLocataire.getText().isEmpty()) {
	            	idLocataire.setText("Prénom du Bailleur");
	            }
	        }
	    });
	    
	    // Ajout d'un écouteur de focus au champ de texte du numéro du Bailleur
	    historique.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (historique.getText().equals("Numéro du Bailleur")) {
	            	historique.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (historique.getText().isEmpty()) {
	            	historique.setText("Numéro du Bailleur");
	            }
	        }
	    });
	    
	   
	    
	    // Ajout d'un écouteur de focus au champ de texte de l'statutPaiement du Bailleur
	    statutPaiement.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (statutPaiement.getText().equals("statutPaiement du Bailleur")) {
	            	statutPaiement.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (statutPaiement.getText().isEmpty()) {
	            	statutPaiement.setText("statutPaiement du Bailleur");
	            }
	        }
	    });
	    
	    retour.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	MainInterfaceEcheance Window4 = new MainInterfaceEcheance("Logiciel de gestion DD", 1400,800);
			    	Window4.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
       });
	    
	    // Ajout d'un écouteur de focus au champ de texte de l'email du Bailleur
	    dateEcheance.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (dateEcheance.getText().equals("Email du Bailleur")) {
	            	dateEcheance.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (dateEcheance.getText().isEmpty()) {
	            	dateEcheance.setText("Email du Bailleur");
	            }
	        }
	    });
	    
	    // Ajout d'un écouteur de focus au champ de texte de l'id du bien
	    montantRetard.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (montantRetard.getText().equals("Id du bien")) {
	            	montantRetard.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (montantRetard.getText().isEmpty()) {
	            	montantRetard.setText("Id du bien");
	            }
	        }
	    });
	
	       
	    container.add(idBail);
	    container.add(idLocataire);
	    container.add(statutPaiement);
	    container.add(dateEcheance);
	    container.add(historique);
	    container.add(retour);
	    //container.add(menuSociete);
	   // container.add(montantLoyer);
	    container.add(montantRetard);
	    container.add(penalite);
	    container.add(commentaire);
	    container.add(montantLoyer);

	    container.add(enregistrer);
	    jlBackground.setBackground(Color.BLACK);
			
	    this.setLocationRelativeTo(null);
	    this.setVisible(true);		
			
			
		enregistrer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				enregistrerButton = true;

		    	String montantLoyerText = montantLoyer.getText();
		    	EcheanceDAO echeanceDAO = new EcheanceDAO();	
		    	int idMax = echeanceDAO.getMaxIdEcheance();
		    	String dateEcheanceText = dateEcheance.getText();
		    	 int idBailInt = Integer.parseInt(idBail.getText());

		    	 int idLocataireInt = Integer.parseInt(idLocataire.getText());
		         String statutPaiementText = statutPaiement.getText();
		         float historiqueInt = Float.parseFloat(historique.getText());
		         float montantLoyerFloat = Float.parseFloat(montantLoyer.getText());
		         float montantRetardFloat = Float.parseFloat(montantRetard.getText());
		         float penaliteFloat = Float.parseFloat(penalite.getText());
		         String commentaireText = commentaire.getText();

		         // Création de l'objet Echeance
		         Echeance echeance = new Echeance(idMax, dateEcheanceText, 
		        		 statutPaiementText, historiqueInt, montantLoyerFloat, montantRetardFloat, penaliteFloat, commentaireText,idLocataireInt,idBailInt);
		         echeanceDAO.addEcheance(echeance);
		    	
		    	
				//BailleurDAO.addBailleur(Bailleur);
				JOptionPane.showMessageDialog(null, "L'écheance a été correctement ajouté à la base de données !", "Message de confirmation", JOptionPane.INFORMATION_MESSAGE);
		    	}
			
		});
	}

	public boolean enregistrerClicked() {
		return enregistrerButton;
	}
	
	/**
	 * Permet de savoir si le bien est une société ou pas
	 */
	
	
	/**
	 * Permet de recuperer le nom du Bailleur
	 */
	public String getidBail() {
		return idBail.getText();
	}
	
	/**
	 * Permet de recuperer le prénom du Bailleur
	 */
	public String getPréidBail() {
		return idLocataire.getText();
	}
	
	/**
	 * Permet de recuperer le numero du Bailleur
	 */
	public String gethistorique() {
		return historique.getText();
	}
	
	/**
	 * Permet de recuperer l'email du Bailleur
	 */
	public String getdateEcheance() {
		return dateEcheance.getText();
	}
	
	/**
	 * Permet de recuperer l'statutPaiement du Bailleur
	 */
	public String getstatutPaiement() {
		return statutPaiement.getText();
	}
	
	/**
	 * Permet de recuperer la raison sociale
	 */
	public String getmontantLoyer() {
		return montantLoyer.getText();
	}
	
	/**
	 * Permet de recuperer l'id du bien
	 */
	public String getmontantRetard() {
		return montantRetard.getText();
	}
	
	/**
	 * Permet de convertir des entiers de String à int
	 * 
	 * @param text : un entier en String
	 * 
	 * @return sa valeur en int
	 */
	public int convertTextToInt(String text, String text1) {
		if (text.equals(text1))
			return 0;
		else
			return Integer.parseInt(text);
	}
	
	/**
	 * Permet d'afficher un texte par défaut si certains champs ne sont pas remplis
	 * 
	 * @param text : un entier en String
	 * 
	 * @return le texte par défaut
	 */
	public String defaultText(String text) {
		if (text == null || text.equals(""))
			text = "Non renseigné";
		return text;
	}

}