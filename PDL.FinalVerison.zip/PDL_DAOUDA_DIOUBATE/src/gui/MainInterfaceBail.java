package gui;

import javax.swing.*;

import dao.BailDAO;

import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

public class MainInterfaceBail extends JFrame {
	
	private JPanel jlBackground;
	private JLabel jlColor;
	private JButton ajoutBail;
	private JButton Bien;
	private JButton Locataire;
	private JButton Bail;
	private JButton Bailleur;
	private JButton modifier;
	private JButton supprimer;
	private JButton Echeance;
	private Container container;

	private AddProperty window;
	
	private boolean addPropertyButton = false;


	public MainInterfaceBail(String title, int width, int height  ) {
		
		this.setTitle(title);
		this.setSize(width, height);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		int buttonWidth = 100; // Largeur du JButton
        int buttonHeight = 30; // Hauteur du JButton
        
        JFrame frame = new JFrame("Supprimer une valeur de la base de données");
        BailDAO bailInfo = new BailDAO();


		jlBackground = new JPanel();
		this.setContentPane(jlBackground);
		Bien = new JButton("Bien");
		Locataire = new JButton("Locataire");
		ajoutBail = new JButton("+ Créer un bail ");
		Bail = new JButton("Bail");
		Bailleur = new JButton("Bailleur");
		supprimer = new JButton("Supprimer");
		modifier = new JButton("Modifier");
		Echeance = new JButton("Echeance");
		container = this.getContentPane();
		
		String[] columnNames = {"id Bail ", "id Bailleur ","id Locataire","type"}; // a changer pour a
		
		
		List<Object[]> dataList = new ArrayList<>();

		for (int i = 1; i < bailInfo.getMaxIdBail(); i++) {
		    dataList.add(new Object[] {
		        bailInfo.getBailId(i),
		        bailInfo.getBailleurId(i),
		        bailInfo.getLocataireId(i),
		        bailInfo.getBailType(i)
		    });
		}

		// Convertir la liste en un tableau à deux dimensions
		Object[][] data = new Object[dataList.size()][];
		for (int i = 0; i < dataList.size(); i++) {
		    data[i] = dataList.get(i);
		}
		
		
		JTable table = new JTable(data, columnNames);
		
	    //table.setBackground(Color.BLACK); // Change to desired color

		
		JScrollPane scrollPane = new JScrollPane(table);
        
        
		 //scrollPane.getViewport().setBackground(Color.BLACK); // Change to desired color

	        
		container.setLayout(null); // Définir le layout sur null pour permettre le positionnement absolu
        
		scrollPane.setBounds(0, 100, 1400, 600); // Adjust bounds as needed
        ajoutBail.setBounds(1200, 50, 150, buttonHeight);
	    Bien.setBounds(500,50  , 100, 30);
	    Locataire.setBounds(600,50,100,30);
	    Bail.setBounds(700,50,100,30);
	    Bailleur.setBounds(800,50,100,30);
	    modifier.setBounds(50,650,100,30);
	    supprimer.setBounds(200,650,100,30);
	    Bailleur.setBounds(800,50,100,30);
	    Echeance.setBounds(400,50,100,30);
	    
        container.add(ajoutBail);
        container.add(Bien);
        container.add(Locataire);
        container.add(Bail);
        container.add(modifier);
        container.add(supprimer);
        container.add(Echeance);
        container.add(Bailleur);

        container.add(scrollPane);
		jlBackground.setBackground(Color.BLACK);

		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		ajoutBail.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	addPropertyButton = true;
		    	CreationBail Window3 = new CreationBail("Logiciel de gestion DD",1400,800);		
		        dispose(); // Ferme l'interface 2
		        
		        
		        
		    }
		});
		
		Locataire.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	MainInterfaceLocataire Window6 = new MainInterfaceLocataire("Logiciel de gestion DD", 1400,800);
			    	Window6.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
			
		});
		
		
		Bailleur.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	MainInterfaceBailleur Window10 = new MainInterfaceBailleur("Logiciel de gestion DD", 1400,800);
			    	Window10.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
			
		});
		Echeance.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	MainInterfaceEcheance Window6 = new MainInterfaceEcheance("Logiciel de gestion DD", 1400,800);
			    	Window6.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
			
		});
		
		Bien.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	MainInterface Window1 = new MainInterface("Logiciel de gestion DD", 1400,800);
			    	Window1.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
			
		});
		
		supprimer.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	// Afficher une boîte de dialogue pour entrer l'ID de la valeur à supprimer
	                String id = JOptionPane.showInputDialog(frame, "Entrez l'ID de la valeur à supprimer:");

	                // Vérifier si l'utilisateur a entré quelque chose
	                if (id != null && !id.isEmpty()) {
	                    // Supprimer la valeur de la base de données (action factice ici)
	                    // Remplacez cette étape par la suppression réelle de la valeur dans votre base de données
	                    // Exemple : database.deleteValue(id);

	                    // Afficher un message indiquant que la valeur a été supprimée avec succès
	                	int idInt = Integer.parseInt(id);
	                	JOptionPane.showMessageDialog(frame, "La valeur avec l'ID " + id + " a été supprimée de votre base de données.", "Suppression réussie", JOptionPane.INFORMATION_MESSAGE);
	                	bailInfo.deleteBien(idInt);
	                	MainInterfaceBail Window1 = new MainInterfaceBail("Logiciel de gestion DD", 1400,800);
				    	Window1.setVisible(true);
				        dispose(); // Ferme l'interface 2
	                } else {
	                    // Afficher un message si l'utilisateur a annulé l'entrée ou n'a rien entré
	                    JOptionPane.showMessageDialog(frame, "Suppression annulée.", "Information", JOptionPane.INFORMATION_MESSAGE);
	                }
			    	
			    }
			
		});
		
		modifier.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        addPropertyButton = true;
		        // Afficher une boîte de dialogue pour entrer l'ID de la valeur à modifier
		        String id = JOptionPane.showInputDialog(null, "Quel bien voulez-vous modifier ?\nSaisissez son ID :");

		        // Vérifier si l'utilisateur a entré quelque chose
		        if (id != null && !id.isEmpty()) {

		            int idInt = Integer.parseInt(id);

		            String typeBail = "Type de Bail";
		            String datePriseEffet = "Date de Prise d'Effet";
		            String duree = "Durée";
		            String dateFin = "Date de Fin";
		            String montantLoyer = "Montant du Loyer";
		            String charges = "Charges";
		            String montantCaution = "Montant de la Caution";
		            String fraisAgence = "Frais d'Agence";
		            String dateEcheance = "Date d'Échéance";
		            String freqRevision = "Fréquence de Révision";
		            String idBailleur = "ID du Bailleur";
		            String idLocataire = "ID du Locataire";
		            String idGarant = "ID du Garant";

		            // Afficher un menu avec des boutons radio pour choisir quel composant modifier
		            String[] components = {
		                typeBail,
		                datePriseEffet,
		                duree,
		                dateFin,
		                montantLoyer,
		                charges,
		                montantCaution,
		                fraisAgence,
		                dateEcheance,
		                freqRevision,
		                idBailleur,
		                idLocataire,
		                idGarant,
		            };

		            String component = (String) JOptionPane.showInputDialog(null, "Choisissez le composant à modifier :",
		                    "Modifier Composant", JOptionPane.QUESTION_MESSAGE, null, components, components[0]);

		            if (component != null && !component.isEmpty()) {
		                // Afficher une boîte de dialogue pour entrer la nouvelle valeur
		                String newValue = JOptionPane.showInputDialog(null, "Entrez la nouvelle valeur pour " + component + " :");

		                // Vérifier si l'utilisateur a entré quelque chose
		                if (newValue != null && !newValue.isEmpty()) {

		                	if (component.equals(typeBail)) {
		                	    bailInfo.updateType(idInt, newValue);
		                	} else if (component.equals(datePriseEffet)) {
		                	    bailInfo.updateDatePriseEffet(idInt, newValue);
		                	} else if (component.equals(duree)) {
		                		int newValueInt = Integer.parseInt(newValue);
		                		bailInfo.updateDuree(idInt, newValueInt);
		                	} else if (component.equals(dateFin)) {
		                		bailInfo.updateDateFin(idInt, newValue);
		                	} else if (component.equals(montantLoyer)) {
		                		float newValueInt = Float.parseFloat(newValue);
		                		bailInfo.updateMontantLoyer(idInt, newValueInt);
		                	} else if (component.equals(charges)) {
		                		float newValueInt = Float.parseFloat(newValue);

		                		bailInfo.updateCharges(idInt, newValueInt);
		                	} else if (component.equals(montantCaution)) {
		                		float newValueInt = Float.parseFloat(newValue);

		                		bailInfo.updateMontantCaution(idInt, newValueInt);
		                	} else if (component.equals(fraisAgence)) {
		                		float newValueInt = Float.parseFloat(newValue);

		                		bailInfo.updateFraisAgence(idInt, newValueInt);
		                	} else if (component.equals(dateEcheance)) {
		                		int newValueInt = Integer.parseInt(newValue);

		                		bailInfo.updateDateEcheance(idInt, newValueInt);
		                	} else if (component.equals(freqRevision)) {
		                		int newValueInt = Integer.parseInt(newValue);

		                		bailInfo.updateFreqRevision(idInt, newValueInt);
		                	} else if (component.equals(idBailleur)) {
		                		int newValueInt = Integer.parseInt(newValue);

		                		bailInfo.updateIdBailleur(idInt, newValueInt);
		                	} else if (component.equals(idLocataire)) {
		                		int newValueInt = Integer.parseInt(newValue);

		                		bailInfo.updateIdLocataire(idInt, newValueInt);
		                	} else if (component.equals(idGarant)) {
		                		int newValueInt = Integer.parseInt(newValue);

		                		bailInfo.updateIdGarant(idInt, newValueInt);
		                	}


		                    // Afficher un message indiquant que la valeur a été modifiée avec succès
		                    JOptionPane.showMessageDialog(null, "La valeur de " + component + " pour le bien avec l'ID " + id +
		                            " a été modifiée en " + newValue + ".", "Modification réussie", JOptionPane.INFORMATION_MESSAGE);

		                    // Appel à la méthode de modification de votre objet
		                    // updateValue(idInt, component, newValue);

		                    // Actualiser l'interface principale
		                    MainInterfaceBail window1 = new MainInterfaceBail("Logiciel de gestion DD", 1400, 800);
		                    window1.setVisible(true);
		                    dispose(); // Ferme l'interface actuelle
		                } else {
		                    // Afficher un message si l'utilisateur a annulé l'entrée ou n'a rien entré
		                    JOptionPane.showMessageDialog(null, "Modification annulée.", "Information", JOptionPane.INFORMATION_MESSAGE);
		                }
		            } else {
		                // Afficher un message si l'utilisateur a annulé la sélection du composant
		                JOptionPane.showMessageDialog(null, "Modification annulée.", "Information", JOptionPane.INFORMATION_MESSAGE);
		            }
		        } else {
		            // Afficher un message si l'utilisateur a annulé l'entrée ou n'a rien entré
		            JOptionPane.showMessageDialog(null, "Modification annulée.", "Information", JOptionPane.INFORMATION_MESSAGE);
		        }
		    }
		});

		
		}
	
	
	/**
	 * Permet de verifier si l'utilisateur a clique sur 'Ajouter bail'
	 * 
	 * @return l'attribut addPropertyButton
	 */
	public boolean addPropertyClicked() {
		return addPropertyButton;
	}
	
	

}
