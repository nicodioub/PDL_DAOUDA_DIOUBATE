// Faire le DAO de Bail avant de pouvoir continuer ca 

package gui;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import dao.*;
import model.*;
import java.awt.*;
import java.awt.event.*;

public class CreationBail extends JFrame {
	
	private JPanel jlBackground;
    private JButton enregistrer;
    private boolean enregistrerButton = false;
	private Container container;
	private JButton retour ;
	private boolean addPropertyButton = false;

		
    // Zone de texte pour le nom du Bail
	// Zone de texte pour le type de bail
	private JTextField typeBail = new JTextField("Type de bail");

	// Zone de texte pour la date de prise d'effet
	private JTextField datePriseEffet = new JTextField("Date de prise d'effet");

	// Zone de texte pour la durée du bail
	private JTextField duree = new JTextField("Durée du bail");

	// Zone de texte pour la date de fin
	private JTextField dateFin = new JTextField("Date de fin");

	// Zone de texte pour le montant du loyer
	private JTextField montantLoyer = new JTextField("Montant du loyer");

	// Zone de texte pour les charges
	private JTextField charges = new JTextField("Charges");

	// Zone de texte pour le montant de la caution
	private JTextField montantCaution = new JTextField("Montant de la caution");

	// Zone de texte pour les frais d'agence
	private JTextField fraisAgence = new JTextField("Frais d'agence");

	// Zone de texte pour la date d'échéance
	private JTextField dateEcheance = new JTextField("Date d'échéance");

	// Zone de texte pour la fréquence de révision
	private JTextField frequenceRevision = new JTextField("Fréquence de révision");

	// Zone de texte pour l'ID du garant
	private JTextField idGarant = new JTextField("ID du garant");

	// Zone de texte pour le nom du garant
	private JTextField idLocataire = new JTextField("id du locataire");

	// Zone de texte pour le prénom du garant
	private JTextField idBien = new JTextField("id du bien");

	// Zone de texte pour l'ID du bailleur
	private JTextField idBailleur = new JTextField("ID du bailleur");

    


    // Création du menu pour indiquer si le bien est une société ou pas
   	
    

	public CreationBail(String title, int width, int height  ) {
			
		this.setTitle(title);
		this.setSize(width, height);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("YYYY-MM-DD"); // Par exemple, "yyyy-MM-dd" pour le format "année-mois-jour"

	    jlBackground = new JPanel();
		this.setContentPane(jlBackground);
		enregistrer = new JButton("Enregistrer");
		container = this.getContentPane();
		container.setLayout(null); // Définir le layout sur null pour permettre le positionnement absolu
			
		retour = new JButton("Retour");
		retour.setBackground(Color.RED);
	    typeBail.setBounds(100,90,150,30);
	    datePriseEffet.setBounds(100,130,150,30);
	    duree.setBounds(100,170,150,30);
	    dateFin.setBounds(100,210,150,30);
	    montantLoyer.setBounds(100,250,150,30);
	    charges.setBounds(100,330,150,30);
	    montantCaution.setBounds(100,410,150,30);
	    fraisAgence.setBounds(100,370,150,30);
	    dateEcheance.setBounds(100,290,150,30);
	    enregistrer.setBounds(300, 650, 150, 30);
	    frequenceRevision.setBounds(100,450,150,30);
	    idGarant.setBounds(100,490,150,30);
	    idLocataire.setBounds(100,530,150,30);
	    idBailleur.setBounds(100,570,150,30);
        retour.setBounds(500,690,75,30);

	    idBien.setBounds(100,50,150,30);
	    
	    
	    // Définir un rendu personnalisé pour le menu déroulant pour l'indicateur societe
	    
	
	    // Ajout d'un écouteur d'événements pour détecter la sélection d'un élément
	   
	    
	    
	    // Ajout d'un écouteur de focus au champ de texte du nom du Bail
	    typeBail.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (typeBail.getText().equals("Nom du Bail")) {
	            	typeBail.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (typeBail.getText().isEmpty()) {
	            	typeBail.setText("Nom du Bail");
	            }
	        }
	    });
	    
	    // Ajout d'un écouteur de focus au champ de texte du prénom du Bail
	    datePriseEffet.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (datePriseEffet.getText().equals("Prénom du Bail")) {
	            	datePriseEffet.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (datePriseEffet.getText().isEmpty()) {
	            	datePriseEffet.setText("Prénom du Bail");
	            }
	        }
	    });
	    
	    // Ajout d'un écouteur de focus au champ de texte du numéro du Bail
	    montantLoyer.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (montantLoyer.getText().equals("Numéro du Bail")) {
	            	montantLoyer.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (montantLoyer.getText().isEmpty()) {
	            	montantLoyer.setText("Numéro du Bail");
	            }
	        }
	    });
	    retour.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	MainInterfaceBail Window4 = new MainInterfaceBail("Logiciel de gestion DD", 1400,800);
			    	Window4.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
       });

	    
	    // Ajout d'un écouteur de focus au champ de texte de la raison sociale
	    charges.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (charges.getText().equals("Raison sociale")) {
	            	charges.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (charges.getText().isEmpty()) {
	            	charges.setText("Raison sociale");
	            }
	        }
	    });
	    
	    // Ajout d'un écouteur de focus au champ de texte de l'duree du Bail
	    duree.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (duree.getText().equals("duree du Bail")) {
	            	duree.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (duree.getText().isEmpty()) {
	            	duree.setText("duree du Bail");
	            }
	        }
	    });
	    
	    // Ajout d'un écouteur de focus au champ de texte de l'email du Bail
	    dateFin.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (dateFin.getText().equals("Email du Bail")) {
	            	dateFin.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (dateFin.getText().isEmpty()) {
	            	dateFin.setText("Email du Bail");
	            }
	        }
	    });
	    
	    // Ajout d'un écouteur de focus au champ de texte de l'id du bien
	    montantCaution.addFocusListener(new FocusListener() {
	        @Override
	        public void focusGained(FocusEvent e) {
	            // Efface le texte indicatif lorsque le champ de texte obtient le focus
	            if (montantCaution.getText().equals("Id du bien")) {
	            	montantCaution.setText("");
	            }
	        }
	
	        @Override
	        public void focusLost(FocusEvent e) {
	            // Restaure le texte indicatif si le champ de texte est vide lorsqu'il perd le focus
	            if (montantCaution.getText().isEmpty()) {
	            	montantCaution.setText("Id du bien");
	            }
	        }
	    });
	
	       
	    container.add(typeBail);
	    container.add(datePriseEffet);
	    container.add(duree);
	    container.add(dateFin);
	    container.add(montantLoyer);
	    container.add(charges);
	    container.add(montantCaution);
	    container.add(enregistrer);
	    container.add(fraisAgence);
	    container.add(dateEcheance);
	    container.add(frequenceRevision);
	    container.add(idGarant);
	    container.add(idLocataire);
        container.add(retour);

	    container.add(idBailleur);
	   // container.add(idBien);
	    jlBackground.setBackground(Color.BLACK);
			
	    this.setLocationRelativeTo(null);
	    this.setVisible(true);		
			
			
		enregistrer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				enregistrerButton = true;

		    	
		    	
		    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); // Format de date

		    	

		    	String typeBailText = typeBail.getText();
		    	String datePriseEffetText = datePriseEffet.getText();

		    	String dureeText = duree.getText();
		    	int dureeInt = Integer.parseInt(dureeText);
		    	String dateFinText = dateFin.getText();
		        //Date dateFin = dateFormat.parse(dateFinText);

		    	String montantLoyerText = montantLoyer.getText();
		    	float loyerInt = Float.parseFloat(montantLoyerText);
		    	String chargesText = charges.getText();
		    	float chargesFloat = Float.parseFloat(chargesText);
		    	String montantCautionText = montantCaution.getText();
		    	float cautionFloat = Float.parseFloat(montantCautionText);
		    	String fraisAgenceText = fraisAgence.getText();
		    	float fraisInt = Float.parseFloat(fraisAgenceText);
		    	String dateEcheanceText = dateEcheance.getText();
		    	int dateEcheanceInt = Integer.parseInt(dateEcheanceText);


		    	String freqRevisionText = frequenceRevision.getText();
		    	int revisionInt = Integer.parseInt(freqRevisionText);

		    	String idBailleurText = idBailleur.getText();
		    	int idBailleurInt = Integer.parseInt(idBailleurText);
		    	String idLocataireText = idLocataire.getText();
		    	int idLocataireInt = Integer.parseInt(idLocataireText);
		    	String idGarantText = idGarant.getText();
		    	int idGarantInt = Integer.parseInt(idGarantText);

		    	
		    	BailDAO BailDAO = new BailDAO();
		    	int idMax = BailDAO.getMaxIdBail() ;
	    	
		    	
		    		
					Bail bail = new Bail(
		    			    idMax,
		    			    idBailleurInt,
		    			    idLocataireInt,
		    			    idGarantInt,
		    			    dureeInt,
		    			    typeBailText,
		    			    datePriseEffetText,
		    			    dateFinText,
		    			    dateEcheanceInt,
		    			    loyerInt,
		    			    fraisInt,
		    			    chargesFloat,
		    			    cautionFloat,
		    			    revisionInt);
							    	
		    				    	
				BailDAO.addBail(bail);
				JOptionPane.showMessageDialog(null, "Le Bail a été correctement ajouté à la base de données !", "Message de confirmation", JOptionPane.INFORMATION_MESSAGE);
		    	}
					});
	}

	public boolean enregistrerClicked() {
		return enregistrerButton;
	}
	
	/**
	 * Permet de savoir si le bien est une société ou pas
	 */
	
	
	/**
	 * Permet de recuperer le nom du Bail
	 */
	public String gettypeBail() {
		return typeBail.getText();
	}
	
	/**
	 * Permet de recuperer le prénom du Bail
	 */
	public String getPrétypeBail() {
		return datePriseEffet.getText();
	}
	
	/**
	 * Permet de recuperer le numero du Bail
	 */
	public String getmontantLoyer() {
		return montantLoyer.getText();
	}
	
	/**
	 * Permet de recuperer l'email du Bail
	 */
	public String getdateFin() {
		return dateFin.getText();
	}
	
	/**
	 * Permet de recuperer l'duree du Bail
	 */
	public String getduree() {
		return duree.getText();
	}
	
	/**
	 * Permet de recuperer la raison sociale
	 */
	public String getcharges() {
		return charges.getText();
	}
	
	/**
	 * Permet de recuperer l'id du bien
	 */
	public String getmontantCaution() {
		return montantCaution.getText();
	}
	
	/**
	 * Permet de convertir des entiers de String à int
	 * 
	 * @param text : un entier en String
	 * 
	 * @return sa valeur en int
	 */
	public int convertTextToInt(String text, String text1) {
		if (text.equals(text1))
			return 0;
		else
			return Integer.parseInt(text);
	}
	
	/**
	 * Permet d'afficher un texte par défaut si certains champs ne sont pas remplis
	 * 
	 * @param text : un entier en String
	 * 
	 * @return le texte par défaut
	 */
	public String defaultText(String text) {
		if (text == null || text.equals(""))
			text = "Non renseigné";
		return text;
	}

}