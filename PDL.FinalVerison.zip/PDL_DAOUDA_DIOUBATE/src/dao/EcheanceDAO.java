package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import model.*;

/**
 * Classe d'acces aux donnees contenues dans la table BIEN
 * 
 * @author Ilyas DAOUDA + Nicolas DIOUBATE
 * @version 2.0
 */
public class EcheanceDAO extends ConnectionDAO {
	/**
	 * Constructor
	 * 
	 */
	public EcheanceDAO() {
		super();
	}
	
	/**
	 * Permet de récupérer l'id macimum et l'incrémente de 1
	 * 
	 * @return (l'Idmax + 1)
	 */
	public int getMaxIdEcheance() {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
        int maxId = 0;
        try {
            // Créer une connexion à la base de données et exécuter une requête pour obtenir le maximum de l'ID
            // Ici, vous devez utiliser votre logique spécifique pour accéder à la base de données
            // Par exemple, si vous utilisez JDBC :
            con = DriverManager.getConnection(URL, LOGIN, PASS);
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT MAX(idEcheance) AS max_id FROM Echeance");
            if (rs.next()) {
                maxId = rs.getInt("max_id");
            }
            // Fermer les ressources
            rs.close();
            stmt.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
			// fermeture du preparedStatement et de la connexion
        	try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (stmt != null) {
					stmt.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
        return (maxId+1);
    }
	
	/**
	 * Permet de convertir une date Java en date SQL
	 * 
	 * @param date : la date Java
	 * @return la date SQL
	 */
	public java.sql.Date convertToSqlDate(java.util.Date date) {
        if (date == null) {
            return null;
        }
        return new java.sql.Date(date.getTime());
    }


	/**
	 * Permet d'ajouter un bien dans la table Echeance 
	 * Le mode est auto-commit par defaut : chaque insertion est validee
	 * 
	 * @param Echeance le bien a ajouter
	 * @return retourne le nombre de lignes ajoutees dans la table
	 */
	public int addEcheance(Echeance Echeance) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans l'insertion.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("INSERT INTO ECHEANCE(idEcheance, dateEcheance, statutPaiement, historique, montantLoyer, montantRetard, penaliteRetard, commentaire, idLocataire, idBail) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			ps.setInt(1, Echeance.getIdBail());
			ps.setString(2, Echeance.getDateEcheance());
			ps.setString(3, Echeance.getStatutPaiement());
			ps.setFloat(4, Echeance.getHistorique());
			ps.setFloat(5, Echeance.getMontantLoyer());
			ps.setFloat(6, Echeance.getMontantRetard());
			ps.setFloat(7, Echeance.getPenaliteRetard());
			ps.setString(8, Echeance.getCommentaire());
			ps.setInt(9, Echeance.getIdLocataire());
			ps.setInt(10, Echeance.getIdBail());

			
			
			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			if (e.getMessage().contains("ORA-00001"))
				System.out.println("Cet identifiant de bien existe déjà. Ajout impossible !");
			else
				e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	/**
	 * Permet de modifier un Echeance dans la table Echeance
	 *  Le mode est auto-commit par defaut : chaque modification est validee
	 * 
	 * @param Echeance le Echeance a modifier
	 * @return retourne le nombre de lignes modifiees dans la table
	 */
	public int updateEcheance(Echeance Echeance) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans la modification.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("UPDATE ECHEANCE SET dateEcheance = ?, statutPaiement = ?, historique = ?, montantLoyer = ?, montantRetard = ?, penaliteRetard = ?, commentaire = ?, idLocataire = ?, idBail = ? WHERE idEcheance = ?");
			ps.setString(1, Echeance.getDateEcheance());
			ps.setString(2, Echeance.getStatutPaiement());
			ps.setFloat(3, Echeance.getHistorique());
			ps.setFloat(4, Echeance.getMontantLoyer());
			ps.setFloat(5, Echeance.getMontantRetard());
			ps.setFloat(6, Echeance.getPenaliteRetard());
			ps.setString(7, Echeance.getCommentaire());
			ps.setInt(8, Echeance.getIdLocataire());
			ps.setInt(9, Echeance.getIdBail());
			ps.setInt(10, Echeance.getIdEcheance());


			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	public int ajoutLoyer(int idLocataire, int dateEcheance, float montantLoyer) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // Connexion à la base de données
	    try {
	        // Tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // Préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE  ECHEANCE SET (dateEcheance, montantLoyer, idLocataire) VALUES (?, ?, ?)");
	        ps.setInt(1, dateEcheance);
	        ps.setFloat(2, montantLoyer);
	        ps.setInt(3, idLocataire);

	        // Exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // Fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}


	public int updateComponent(Bien bien) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans la modification.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("UPDATE BIEN set typeBien = ?, surfaceBien = ?, codePostal = ?, isMaisonIndividuelle = ?, isAppartement = ?, nombreChambre = ?, anneeConstruction = ?, arrondissement = ?, ville = ?, numAppartement = ?, numEtage = ?, numRue = ?, typeRue = ?, nomRue = ?, nomResidence = ?, isChauffageIndividuel = ?, typeChauffage = ?, isJardin = ?, surfaceJardin = ?, isMeuble = ?, isTerrain = ?, surfaceTerrain = ?, isEscalier = ?, isCave = ?, isSousSol = ?, isCour = ?, surfaceCour = ?, isBalcon = ?, surfaceBalcon = ?, isTerrasse = ?, surfaceTerrasse = ?, descriptionMeuble = ? WHERE id = ?");
			ps.setString(1, bien.getType());
			ps.setFloat(2, bien.getSurface());
			ps.setInt(3, bien.getCodePostal());
			ps.setBoolean(4, bien.isMaisonIndividuelle());
			ps.setBoolean(5, bien.isAppartement());
			ps.setInt(6, bien.getNombreChambres());
			ps.setInt(7, bien.getAnneeConstruction());
			ps.setInt(8, bien.getArrondissement());
			ps.setString(9, bien.getVille());
			ps.setInt(10, bien.getNumAppartement());
			ps.setInt(11, bien.getEtage());
			ps.setInt(12, bien.getNumRue());
			ps.setString(13, bien.getTypeRue());
			ps.setString(14, bien.getNomRue());
			ps.setString(15, bien.getResidence());
			ps.setBoolean(16, bien.aChauffageIndividuel());
			ps.setString(17, bien.getTypeChauffage());	
			ps.setBoolean(18, bien.aUnJardin());
			ps.setFloat(19, bien.getSurfaceJardin());
			ps.setBoolean(20, bien.isMeuble());
			ps.setBoolean(21, bien.aUnTerrain());
			ps.setFloat(22, bien.getSurfaceTerrain());
			ps.setBoolean(23, bien.aUnEscalier());
			ps.setBoolean(24, bien.aUneCave());
			ps.setBoolean(25, bien.aUnSousSol());
			ps.setBoolean(26, bien.aUneCour());
			ps.setFloat(27, bien.getSurfaceCour());
			ps.setBoolean(28, bien.aUnBalcon());
			ps.setFloat(29, bien.getSurfaceBalcon());
			ps.setBoolean(30, bien.aUneTerrasse());
			ps.setFloat(31, bien.getSurfaceTerrasse());
			ps.setString(32, bien.getDescriptionMeubles());
			ps.setInt(33, bien.getIdBien());

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	public int updateDateEcheance(int idLocataire, int nouvelleDateEcheance) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // Connexion à la base de données
	    try {
	        // Tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // Préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE ECHEANCE SET dateEcheance = ? WHERE idEcheance = ?");
	        ps.setInt(1, nouvelleDateEcheance);
	        ps.setInt(2, idLocataire);

	        // Exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // Fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}


	
	public int updateHistorique(int idEcheance, int nouvelHistorique) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE ECHEANCE SET historique = ? WHERE idEcheance = ?");
        ps.setInt(1, nouvelHistorique);
        ps.setInt(2, idEcheance);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

	public int updateStatutPaiement(int idEcheance, String nouveauStatut) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE ECHEANCE SET statutPaiement = ? WHERE idEcheance = ?");
        ps.setString(1, nouveauStatut);
        ps.setInt(2, idEcheance);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

public int updateMontantRetard(int idEcheance, float nouveauMontantRetard) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE ECHEANCE SET montantRetard = ? WHERE idEcheance = ?");
        ps.setFloat(1, nouveauMontantRetard);
        ps.setInt(2, idEcheance);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

	
	public int updateMontantLoyer(int idEcheance, float nouveauMontantLoyer) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE ECHEANCE SET montantLoyer = ? WHERE idEcheance = ?");
        ps.setFloat(1, nouveauMontantLoyer);
        ps.setInt(2, idEcheance);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

	public int updatePenaliteRetard(int idEcheance, float nouvellePenaliteRetard) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE ECHEANCE SET penaliteRetard = ? WHERE idEcheance = ?");
        ps.setFloat(1, nouvellePenaliteRetard);
        ps.setInt(2, idEcheance);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

	public int updateCommentaire(int idEcheance, String nouveauCommentaire) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE ECHEANCE SET commentaire = ? WHERE idEcheance = ?");
        ps.setString(1, nouveauCommentaire);
        ps.setInt(2, idEcheance);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

	public int updateIdLocataire(int idEcheance, int nouvelIdLocataire) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE ECHEANCE SET idLocataire = ? WHERE idEcheance = ?");
        ps.setInt(1, nouvelIdLocataire);
        ps.setInt(2, idEcheance);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

	public int updateIdBail(int idEcheance, int nouvelIdBail) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE ECHEANCE SET idBail = ? WHERE idEcheance = ?");
        ps.setInt(1, nouvelIdBail);
        ps.setInt(2, idEcheance);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}


	/**
	 * Permet de supprimer un bien par identifiant dans la table BIEN.
	 * Le mode est auto-commit par defaut : chaque suppression est validee
	 * 
	 * @param idBien l'identifiant du bien à supprimer
	 * @return retourne le nombre de lignes supprimees dans la table
	 */
	public int deleteBien(int idBien) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, le ? represente la valeur de l'ID
			// a communiquer dans la suppression.
			// le getter permet de recuperer la valeur de l'ID du bien
			ps = con.prepareStatement("DELETE FROM BIEN WHERE idBien = ?");
			ps.setInt(1, idBien);

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	/**
	 * Permet de recuperer un bien a partir de sa reference
	 * 
	 * @param idBien l'identifiant du bien a recuperer
	 * @return le bien trouve; null si aucun bien ne correspond a cet identifiant
	 */
	
	
	public Bien getBien(int idBien) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Bien returnValue = null;

		// connexion a la base de donnees
		try {

			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM BIEN WHERE idBien = ?");
			ps.setInt(1, idBien);

			// on execute la requete
			// rs contient un pointeur situe juste avant la premiere ligne retournee
			rs = ps.executeQuery();
			// passe a la premiere (et unique) ligne retournee
			if (rs.next()) {
				returnValue = new Bien(rs.getInt("idBien"), rs.getString("typeBien"), 
									   rs.getFloat("surfaceBien"), rs.getInt("codePostal"),
									   rs.getBoolean("isMaisonIndividuelle"), rs.getBoolean("isAppartement"),
									   rs.getInt("nombreChambre"), rs.getInt("anneeConstruction"),
									   rs.getInt("arrondissement"), rs.getString("ville"),
									   rs.getInt("numAppartement"), rs.getInt("numEtage"),
									   rs.getInt("numRue"), rs.getString("typeRue"),
									   rs.getString("nomRue"), rs.getString("nomResidence"),
									   rs.getBoolean("isChauffageIndividuel"), rs.getString("typeChauffage"),
							           rs.getBoolean("isJardin"), rs.getFloat("surfaceJardin"),
								   	   rs.getBoolean("isMeuble"), rs.getBoolean("isTerrain"),
									   rs.getFloat("surfaceTerrain"), rs.getBoolean("isEscalier"),
									   rs.getBoolean("isCave"), rs.getBoolean("isSousSol"),
									   rs.getBoolean("isCour"), rs.getFloat("surfaceCour"),
									   rs.getBoolean("isBalcon"), rs.getFloat("surfaceBalcon"),
									   rs.getBoolean("isTerrasse"), rs.getFloat("surfaceTerrasse"),
									   rs.getString("descriptionMeuble"));
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du ResultSet, du PreparedStatement et de la Connexion
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	public String[] getBienPartiel(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String[] returnValue = new String[2]; // Pour stocker id et type

	    // Connexion à la base de données
	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT idBien, typeBien, surfaceBien, adresse, ville FROM BIEN WHERE idBien = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue[0] = rs.getString("idBien"); // Récupération de id
	            returnValue[1] = rs.getString("typeBien"); // Récupération de type
	            returnValue[2] = rs.getString("surfaceBien"); // Récupération de type
	            returnValue[3] = rs.getString("adresse"); // Récupération de type
	            returnValue[4] = rs.getString("ville"); // Récupération de type


	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public String getEcheanceId(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT idEcheance FROM Echeance WHERE idEcheance = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("idEcheance"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public String getEcheanceLoyer(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT montantLoyer FROM ECHEANCE WHERE idEcheance = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("montantLoyer"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public String getEcheanceStatut(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT statutPaiement FROM ECHEANCE WHERE idEcheance = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("statutPaiement"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public String getEcheanceRetard(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT montantRetard FROM ECHEANCE WHERE idEcheance = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("montantRetard"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}

	
	public String getEcheanceHistorique(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT historique FROM ECHEANCE WHERE idEcheance = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("historique"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public void addEcheance(int idLocataire, int jourEcheance, double montantLoyer) {
	    Connection con = null;
	    PreparedStatement ps = null;

	    try {
	        // Connexion à la base de données
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // Préparer l'instruction SQL pour insérer une nouvelle échéance
	        String sql = "INSERT INTO ECHEANCE (idEcheance, dateEcheance, statutPaiement, historique, montantLoyer, montantRetard, penaliteRetard, commentaire, idLocataire, idBail) " +
	                     "VALUES (ECHEANCE_SEQ.NEXTVAL, ?, 'impayé', 0, ?, ?, 0, '', ?, ?)";

	        ps = con.prepareStatement(sql);
	        ps.setInt(1, jourEcheance);  // La date d'échéance est le jour du mois
	        ps.setDouble(2, montantLoyer);  // Le montant du loyer
	        ps.setDouble(3, montantLoyer);  // Le montant de retard initial est le montant du loyer
	        ps.setInt(4, idLocataire);  // L'ID du locataire
	        ps.setInt(5, idLocataire);  // L'ID du bail, ici il est supposé être le même que l'ID du locataire, ajustez si nécessaire

	        // Exécuter l'insertion
	        ps.executeUpdate();

	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        // Fermeture du PreparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (SQLException ignore) {}
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (SQLException ignore) {}
	    }
	}

	
	public int reglerLoyer(int idEcheance, int dateEcheance, float montantPaye) {
	    Connection con = null;
	    PreparedStatement psUpdate = null;
	    PreparedStatement psSelect = null;
	    int returnValue = 0;

	    try {
	        // Connexion à la base de données
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // Obtenir les informations actuelles de l'échéance
	        psSelect = con.prepareStatement("SELECT montantRetard = ? ,  historique = ?  FROM ECHEANCE WHERE idEcheance = ?");
	        psSelect.setInt(3, idEcheance);
	        psSelect.setFloat(2, montantPaye);
	        psSelect.setFloat(1, montantPaye);


	        ResultSet rs = psSelect.executeQuery();

	        if (rs.next()) {
	            int dateEcheanceStr = rs.getInt("dateEcheance");
	            float montantLoyer = rs.getFloat("montantLoyer");
	            float montantRetard = rs.getFloat("montantRetard");
	            float penaliteRetard = rs.getFloat("penaliteRetard");
	            float historique = rs.getFloat("historique");

	            // Calculer le nouveau montant de retard
	            Float nouveauMontantRetard = montantRetard - dateEcheance;

	            // Si le montant payé est supérieur au montant en retard, ajouter l'excédent à l'historique
	            Float montantRestant = Math.max(0, dateEcheance - montantRetard);
	            Float nouvelHistorique = historique + montantRestant;

	            // Vérifier si le paiement est en retard
	           

	            // Appliquer une pénalité si nécessaire
	            if (dateEcheanceStr - montantPaye> 0) {
	                penaliteRetard += 10;  // Ajoute une pénalité de 10 (ou tout autre montant défini)
	            }

	            // Déterminer le nouveau statut de paiement
	            String statutPaiement = (nouveauMontantRetard <= 0) ? "en règle" : "impayé";

	            // Préparer l'instruction SQL pour mettre à jour l'échéance
	            psUpdate = con.prepareStatement("UPDATE ECHEANCE SET montantRetard = ?, penaliteRetard = ?, historique = ?, statutPaiement = ? WHERE idEcheance = ?");
	            psUpdate.setFloat(1, Math.max(0, nouveauMontantRetard));  // Assurez-vous que le montant de retard ne soit pas négatif
	            psUpdate.setFloat(2, penaliteRetard);
	            psUpdate.setFloat(3, nouvelHistorique);
	            psUpdate.setString(4, statutPaiement);
	            psUpdate.setInt(5, idEcheance);

	            // Exécuter la requête
	            returnValue = psSelect.executeUpdate();
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (psSelect != null) {
	                psSelect.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (psUpdate != null) {
	                psUpdate.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}

	public String getBienAdresse(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT numRue, typeRue, nomRue FROM BIEN WHERE idBien = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	        	 returnValue = rs.getString("numRue") + " " + rs.getString("typeRue") + " " + rs.getString("nomRue"); }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public String getBienVille(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT ville FROM BIEN WHERE idBien = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("ville"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}

	/**
	 * Permet de recuperer tous les baux stockes dans la table Echeance
	 * 
	 * @return une ArrayList de Echeance
	 */	
	public ArrayList<Echeance> getList() {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Echeance> returnValue = new ArrayList<Echeance>();

		// connexion a la base de donnees
		try {
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM Echeance ORDER BY idEcheance");

			// on execute la requete
			rs = ps.executeQuery();
			// on parcourt les lignes du resultat
			while (rs.next()) {
				returnValue.add(new Echeance(rs.getInt("idEcheance"),
                        rs.getString("dateEcheance"),
                        rs.getString("statutPaiement"),
                        rs.getFloat("historique"),
                        rs.getFloat("montantLoyer"),
                        rs.getInt("montantRetard"),
                        rs.getFloat("penaliteRetard"),
                        rs.getString("commentaire"),
                        rs.getInt("idLocataire"),
                        rs.getInt("idBail")));

			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du rs, du preparedStatement et de la connexion
			try {
				if (rs != null)
					rs.close();
			} catch (Exception ignore) {
			}
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
}