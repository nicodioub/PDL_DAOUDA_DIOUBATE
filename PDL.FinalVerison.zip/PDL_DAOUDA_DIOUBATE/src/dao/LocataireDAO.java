package dao;
import java.sql.*;
import java.util.ArrayList;
import model.Locataire;

/**
 * Classe d'acces aux donnees contenues dans la table Locataire
 * 
 * @author Ilyas DAOUDA + Nicolas DIOUBATE
 * @version 1.0
 * */
public class LocataireDAO extends ConnectionDAO {
	/**
	 * Constructeur de la classe
	 * 
	 */
	public LocataireDAO() {
		super();
	}
	
	/**
	 * Convertit true en 1 et false en 0
	 * 
	 * @param bool : un booléen
	 * @return 1 ou 0
	 */
	public int convertToBinary(boolean bool) {
		if (bool == true)
			return 1;
		else
			return 0;
	}
	
	/**
	 * Permet de récupérer l'id maximum et l'incrémente de 1
	 * 
	 * @return (l'Idmax + 1)
	 */
	public int getMaxIdLocataire() {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
        int maxId = 0;
        try {
            // Créer une connexion à la base de données et exécuter une requête pour obtenir le maximum de l'ID
            // Ici, vous devez utiliser votre logique spécifique pour accéder à la base de données
            // Par exemple, si vous utilisez JDBC :
            con = DriverManager.getConnection(URL, LOGIN, PASS);
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT MAX(idLocataire) AS max_id FROM LOCATAIRE");
            if (rs.next()) {
                maxId = rs.getInt("max_id");
            }
            // Fermer les ressources
            rs.close();
            stmt.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
			// fermeture du preparedStatement et de la connexion
        	try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (stmt != null) {
					stmt.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
        return (maxId+1);
    }

	/**
	 * Permet d'ajouter un Locataire dans la table Locataire
	 * Le mode est auto-commit par defaut : chaque insertion est validee
	 * 
	 * @param Locataire le Locataire a ajouter
	 * @return retourne le nombre de lignes ajoutees dans la table
	 */
	public int addLocataire(Locataire Locataire) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans l'insertion.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("INSERT INTO Locataire(idLocataire, nom, prenom, adresse, email, telephone, societe, raisonSociale, idBien) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)");
			ps.setInt(1, getMaxIdLocataire());
			ps.setString(2, Locataire.getNomLocataire());
			ps.setString(3, Locataire.getPrenomLocataire());
			ps.setString(4, Locataire.getAdresse());
			ps.setString(5, Locataire.getEmailLocataire());
			ps.setString(6, Locataire.getNumeroLocataire()); // On a mis dans les tables 
			ps.setInt(7, convertToBinary(Locataire.getSociete()));
			ps.setString(8, Locataire.getRaisonSociale());
			ps.setInt(9, Locataire.getIdBien());
			

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			if (e.getMessage().contains("ORA-00001"))
				System.out.println("Cet identifiant de Locataire existe déjà. Ajout impossible !");
			else
				e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try { 
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	/**
	 * Permet de modifier un Locataire dans la table Locataire
	 * Le mode est auto-commit par defaut : chaque modification est validee
	 * 
	 * @param Locataire le Locataire a modifier
	 * @return retourne le nombre de lignes modifiees dans la table
	 */
	public int updateLocataire(Locataire Locataire) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans la modification.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("UPDATE Locataire set nom = ?, prenom = ?, adresse = ?, email = ?, telephone = ?, societe = ?, raisonSociale = ?, idBien =?, WHERE idLocataire = ?");
			ps.setString(1, Locataire.getNomLocataire());
			ps.setString(2, Locataire.getPrenomLocataire());
			ps.setString(3, Locataire.getAdresse());
			ps.setString(4, Locataire.getEmailLocataire());
			ps.setString(5, Locataire.getNumeroLocataire());
			ps.setBoolean(6, Locataire.getSociete());
			ps.setString(7, Locataire.getRaisonSociale());
			ps.setInt(8, Locataire.getIdBien());
			ps.setInt(9, Locataire.getIdBien());

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
		
		
		
	}
	public int updateNom(int idLocataire, String nom) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // connexion à la base de données
	    try {
	        // tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE Locataire SET nom = ? WHERE idLocataire = ?");
	        ps.setString(1, nom);
	        ps.setInt(2, idLocataire);

	        // exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public int updatePrenom(int idLocataire, String nom) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // connexion à la base de données
	    try {
	        // tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE Locataire SET prenom = ? WHERE idLocataire = ?");
	        ps.setString(1, nom);
	        ps.setInt(2, idLocataire);

	        // exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public int updateAdresse(int idLocataire, String nom) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // connexion à la base de données
	    try {
	        // tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE Locataire SET adresse = ? WHERE idLocataire = ?");
	        ps.setString(1, nom);
	        ps.setInt(2, idLocataire);

	        // exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public int updateEmail(int idLocataire, String nom) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // connexion à la base de données
	    try {
	        // tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE Locataire SET email = ? WHERE idLocataire = ?");
	        ps.setString(1, nom);
	        ps.setInt(2, idLocataire);

	        // exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public int updateTelephone(int idLocataire, String nom) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // connexion à la base de données
	    try {
	        // tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE Locataire SET telephone = ? WHERE idLocataire = ?");
	        ps.setString(1, nom);
	        ps.setInt(2, idLocataire);

	        // exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public int updateSociete(int idLocataire, int nom) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // connexion à la base de données
	    try {
	        // tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE Locataire SET societe = ? WHERE idLocataire = ?");
	        ps.setInt(1, nom);
	        ps.setInt(2, idLocataire);

	        // exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public int updateRaisonSociale(int idLocataire, String nom) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // connexion à la base de données
	    try {
	        // tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE Locataire SET raisonSociale = ? WHERE idLocataire = ?");
	        ps.setString(1, nom);
	        ps.setInt(2, idLocataire);

	        // exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	
	/**
	 * Permet de supprimer un Locataire par idLocataire dans la table Locataire
	 * Le mode est auto-commit par defaut : chaque suppression est validee
	 * 
	 * @param idLocataire l'identifiant du Locataire à supprimer
	 * @return retourne le nombre de lignes supprimees dans la table
	 */
	public int deleteLocataire(int idLocataire) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, le ? represente la valeur de l'identifiant
			// a communiquer dans la suppression.
			// le getter permet de recuperer la valeur de l'identifiant du Locataire
			ps = con.prepareStatement("DELETE FROM Locataire WHERE idLocataire = ?");
			ps.setInt(1, idLocataire);

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}


	/**
	 * Permet de recuperer un Locataire a partir de son identifiant
	 * 
	 * @param idLocataire l'identifiant du fournisseur a recuperer
	 * @return le Locataire trouve; null si aucun Locataire ne correspond a cet identifiant
	 */
	public Locataire getLocataire(int idLocataire) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Locataire returnValue = null;

		// connexion a la base de donnees
		try {

			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM Locataire WHERE idLocataire = ?");
			ps.setInt(1, idLocataire);

			// on execute la requete
			// rs contient un pointeur situe juste avant la premiere ligne retournee
			rs = ps.executeQuery();
			// passe a la premiere (et unique) ligne retournee
			if (rs.next()) {
				returnValue = new Locataire(rs.getInt("idLocataire"), rs.getString("nom"), rs.getString("prenom"),
									        rs.getString("adresse"), rs.getString("email"), rs.getString("telephone"),
									        rs.getBoolean("societe"), rs.getString("raisonSociale"), rs.getInt("idBien"));
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du ResultSet, du PreparedStatement et de la Connexion
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	/**
	 * Permet de recuperer tous les Locataires stockes dans la table Locataire
	 * 
	 * @return une ArrayList de Locataire
	 */
	public ArrayList<Locataire> getList() {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Locataire> returnValue = new ArrayList<Locataire>();

		// connexion a la base de donnees
		try {
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM Locataire ORDER BY idLocataire");

			// on execute la requete
			rs = ps.executeQuery();
			// on parcourt les lignes du resultat
			while (rs.next()) {
				returnValue.add(new Locataire(rs.getInt("idLocataire"), rs.getString("nom"), rs.getString("prenom"),
				        rs.getString("adresse"), rs.getString("email"), rs.getString("telephone"),
				        rs.getBoolean("societe"), rs.getString("raisonSociale"), rs.getInt("idBien")));
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du rs, du preparedStatement et de la connexion
			try {
				if (rs != null)
					rs.close();
			} catch (Exception ignore) {
			}
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	/**
	 * ATTENTION : Cette méthode n'a pas vocation à être executée lors d'une utilisation normale du programme !
	 * Elle existe uniquement pour TESTER les méthodes écrites au-dessus !
	 * 
	 * @param args non utilisés
	 * @throws SQLException si une erreur se produit lors de la communication avec la BDD
	 */
	/*
	public static void main(String[] args) throws SQLException {
		int returnValue;
		LocataireDAO LocataireDAO = new LocataireDAO();
		// Ce test va utiliser directement votre BDD, on essaie d'éviter les collisions avec vos données en prenant de grands ID
		int[] ids = {424242, 424243, 424244};
		// test du constructeur
		Locataire s1 = new Locataire(ids[0], "Ilyas", "Daouda", "Volta");
		Locataire s2 = new Locataire(ids[1], "Nicolas", "Dioubate", "Turing");
		Locataire s3 = new Locataire(ids[2], "Chloe", "Cabot", "Charliat");
		// test de la methode add
		returnValue = LocataireDAO.addLocataire(s1);
		System.out.println(returnValue + " Locataire ajoute");
		returnValue = LocataireDAO.addLocataire(s2);
		System.out.println(returnValue + " Locataire ajoute");
		returnValue = LocataireDAO.addLocataire(s3);
		System.out.println(returnValue + " Locataire ajoute");
		System.out.println();
		
		// test de la methode get
		Locataire sg = LocataireDAO.getLocataire(1);
		// appel implicite de la methode toString de la classe Object (a eviter)
		System.out.println(sg);
		System.out.println();
		
		// test de la methode getList
		ArrayList<Locataire> list = LocataireDAO.getList();
		for (Locataire s : list) {
			// appel explicite de la methode toString de la classe Object (a privilegier)
			System.out.println(s.toString());
		}
		System.out.println();
		// test de la methode delete
		// On supprime les 3 Locataires qu'on a créé
		returnValue = 0;
		for (int id : ids) {
//			returnValue = LocataireDAO.deleteLocataire(id);
			System.out.println(returnValue + " fournisseur supprime");
		}
		
		System.out.println();
	}
	*/

	/**
	 * ATTENTION : Cette méthode n'a pas vocation à être executée lors d'une utilisation normale du programme !
	 * Elle existe uniquement pour TESTER les méthodes écrites au-dessus !
	 * 
	 * @param args non utilisés
	 * @throws SQLException si une erreur se produit lors de la communication avec la BDD
	 */
	
	
	public String getLocataireId(int idLocataire) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT idLocataire FROM LOCATAIRE WHERE idLocataire = ?");
	        ps.setInt(1, idLocataire);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("idLocataire"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public String getLocataireNom(int idLocataire) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT nom FROM LOCATAIRE WHERE idLocataire = ?");
	        ps.setInt(1, idLocataire);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("nom"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public String getLocatairePrenom(int idLocataire) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT prenom FROM LOCATAIRE WHERE idLocataire = ?");
	        ps.setInt(1, idLocataire);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("prenom"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public String getLocataireAdresse(int idLocataire) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT adresse FROM LOCATAIRE WHERE idLocataire = ?");
	        ps.setInt(1, idLocataire);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("adresse"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public String getLocataireEmail(int idLocataire) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT email FROM LOCATAIRE WHERE idLocataire = ?");
	        ps.setInt(1, idLocataire);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("email"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
}