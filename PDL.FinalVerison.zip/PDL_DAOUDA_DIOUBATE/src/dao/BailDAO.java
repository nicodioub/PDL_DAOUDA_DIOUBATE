package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import model.*;

/**
 * Classe d'acces aux donnees contenues dans la table BIEN
 * 
 * @author Ilyas DAOUDA + Nicolas DIOUBATE
 * @version 2.0
 */
public class BailDAO extends ConnectionDAO {
	/**
	 * Constructor
	 * 
	 */
	public BailDAO() {
		super();
	}
	
	/**
	 * Permet de récupérer l'id macimum et l'incrémente de 1
	 * 
	 * @return (l'Idmax + 1)
	 */
	public int getMaxIdBail() {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
        int maxId = 0;
        try {
            // Créer une connexion à la base de données et exécuter une requête pour obtenir le maximum de l'ID
            // Ici, vous devez utiliser votre logique spécifique pour accéder à la base de données
            // Par exemple, si vous utilisez JDBC :
            con = DriverManager.getConnection(URL, LOGIN, PASS);
            stmt = con.createStatement();
            rs = stmt.executeQuery("SELECT MAX(idBail) AS max_id FROM BAIL");
            if (rs.next()) {
                maxId = rs.getInt("max_id");
            }
            // Fermer les ressources
            rs.close();
            stmt.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
			// fermeture du preparedStatement et de la connexion
        	try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (stmt != null) {
					stmt.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
        return (maxId+1);
    }
	
	/**
	 * Permet de convertir une date Java en date SQL
	 * 
	 * @param date : la date Java
	 * @return la date SQL
	 */
	public java.sql.Date convertToSqlDate(java.util.Date date) {
        if (date == null) {
            return null;
        }
        return new java.sql.Date(date.getTime());
    }


	/**
	 * Permet d'ajouter un bien dans la table BAIL 
	 * Le mode est auto-commit par defaut : chaque insertion est validee
	 * 
	 * @param bail le bien a ajouter
	 * @return retourne le nombre de lignes ajoutees dans la table
	 */
	public int addBail(Bail bail) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans l'insertion.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("INSERT INTO BAIL(idBail, typeBail, datePriseEffet, duree, dateFin, montantLoyer, charges, montantCaution, fraisAgence, dateEcheance, freqRevision, idBailleur, idLocataire, idGarant) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			ps.setInt(1, bail.getIdBail());
			ps.setString(2, bail.getType());
			ps.setString(3, bail.getDateDebut());
			ps.setInt(4, bail.getDuree());
			ps.setString(5, bail.getDateFin());
			ps.setFloat(6, bail.getMontantLoyer());
			ps.setFloat(7, bail.getCharges());
			ps.setFloat(8, bail.getMontantCaution());
			ps.setFloat(9, bail.getFraisAgence());
			ps.setInt(10, bail.getDateEcheance());
			ps.setInt(11, bail.getFrequenceRevisionLoyer());
			ps.setInt(12, bail.getIdBailleur());
			ps.setInt(13, bail.getIdLocataire());
			ps.setInt(14, bail.getIdGarant());
			
			
			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			if (e.getMessage().contains("ORA-00001"))
				System.out.println("Cet identifiant de bien existe déjà. Ajout impossible !");
			else
				e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	/**
	 * Permet de modifier un bail dans la table Bail
	 *  Le mode est auto-commit par defaut : chaque modification est validee
	 * 
	 * @param bail le bail a modifier
	 * @return retourne le nombre de lignes modifiees dans la table
	 */
	public int updateBail(Bail bail) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans la modification.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("UPDATE BAIL set typeBail = ?, datePriseEffet = ?, duree = ?, dateFin = ?, montantLoyer = ?, charges = ?, montantCaution = ?, fraisAgence = ?, dateEcheance = ?, freqRevision = ?, idBailleur = ?, idLocataire = ?, idGarant = ? WHERE idBail = ?");
			ps.setString(1, bail.getType());
			ps.setString(2, bail.getDateDebut());
			ps.setInt(3, bail.getDuree());
			ps.setString(4, bail.getDateFin());
			ps.setFloat(5, bail.getMontantLoyer());
			ps.setFloat(6, bail.getCharges());
			ps.setFloat(7, bail.getMontantCaution());
			ps.setFloat(8, bail.getFraisAgence());
			ps.setInt(9, bail.getDateEcheance());
			ps.setInt(10, bail.getFrequenceRevisionLoyer());
			ps.setInt(11, bail.getIdBailleur());
			ps.setInt(12, bail.getIdLocataire());
			ps.setInt(13, bail.getIdGarant());
			ps.setInt(14, getMaxIdBail());

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	public int updateComponent(Bien bien) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, chaque ? represente une valeur
			// a communiquer dans la modification.
			// les getters permettent de recuperer les valeurs des attributs souhaites
			ps = con.prepareStatement("UPDATE BIEN set typeBien = ?, surfaceBien = ?, codePostal = ?, isMaisonIndividuelle = ?, isAppartement = ?, nombreChambre = ?, anneeConstruction = ?, arrondissement = ?, ville = ?, numAppartement = ?, numEtage = ?, numRue = ?, typeRue = ?, nomRue = ?, nomResidence = ?, isChauffageIndividuel = ?, typeChauffage = ?, isJardin = ?, surfaceJardin = ?, isMeuble = ?, isTerrain = ?, surfaceTerrain = ?, isEscalier = ?, isCave = ?, isSousSol = ?, isCour = ?, surfaceCour = ?, isBalcon = ?, surfaceBalcon = ?, isTerrasse = ?, surfaceTerrasse = ?, descriptionMeuble = ? WHERE id = ?");
			ps.setString(1, bien.getType());
			ps.setFloat(2, bien.getSurface());
			ps.setInt(3, bien.getCodePostal());
			ps.setBoolean(4, bien.isMaisonIndividuelle());
			ps.setBoolean(5, bien.isAppartement());
			ps.setInt(6, bien.getNombreChambres());
			ps.setInt(7, bien.getAnneeConstruction());
			ps.setInt(8, bien.getArrondissement());
			ps.setString(9, bien.getVille());
			ps.setInt(10, bien.getNumAppartement());
			ps.setInt(11, bien.getEtage());
			ps.setInt(12, bien.getNumRue());
			ps.setString(13, bien.getTypeRue());
			ps.setString(14, bien.getNomRue());
			ps.setString(15, bien.getResidence());
			ps.setBoolean(16, bien.aChauffageIndividuel());
			ps.setString(17, bien.getTypeChauffage());	
			ps.setBoolean(18, bien.aUnJardin());
			ps.setFloat(19, bien.getSurfaceJardin());
			ps.setBoolean(20, bien.isMeuble());
			ps.setBoolean(21, bien.aUnTerrain());
			ps.setFloat(22, bien.getSurfaceTerrain());
			ps.setBoolean(23, bien.aUnEscalier());
			ps.setBoolean(24, bien.aUneCave());
			ps.setBoolean(25, bien.aUnSousSol());
			ps.setBoolean(26, bien.aUneCour());
			ps.setFloat(27, bien.getSurfaceCour());
			ps.setBoolean(28, bien.aUnBalcon());
			ps.setFloat(29, bien.getSurfaceBalcon());
			ps.setBoolean(30, bien.aUneTerrasse());
			ps.setFloat(31, bien.getSurfaceTerrasse());
			ps.setString(32, bien.getDescriptionMeubles());
			ps.setInt(33, bien.getIdBien());

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	public int updateTypeDeBien(int idLocataire, String nouveauTypeDeBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // connexion à la base de données
	    try {
	        // tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE Locataire SET typeBien = ? WHERE idLocataire = ?");
	        ps.setString(1, nouveauTypeDeBien);
	        ps.setInt(2, idLocataire);

	        // exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}

	
	public int updateSurface(int idLocataire, int nouvelleSurface) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // connexion à la base de données
	    try {
	        // tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE Bien SET surfaceBien = ? WHERE idBien = ?");
	        ps.setInt(1, nouvelleSurface);
	        ps.setInt(2, idLocataire);

	        // exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public int deleteBail(int idBail) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, le ? represente la valeur de l'identifiant
			// a communiquer dans la suppression.
			// le getter permet de recuperer la valeur de l'identifiant du Locataire
			ps = con.prepareStatement("DELETE FROM Locataire WHERE idLocataire = ?");
			ps.setInt(1, idBail);

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}


	public int updateType(int idLocataire, String nom) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // connexion à la base de données
	    try {
	        // tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE BAIL SET typeBail = ? WHERE idBail = ?");
	        ps.setString(1, nom);
	        ps.setInt(2, idLocataire);

	        // exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}

	public int updateDatePriseEffet(int idLocataire, String nom) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // connexion à la base de données
	    try {
	        // tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE BAIL SET datePriseEffet = ? WHERE idBail = ?");
	        ps.setString(1, nom);
	        ps.setInt(2, idLocataire);

	        // exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}

		
	public int updateDuree(int idLocataire, int nom) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    int returnValue = 0;

	    // connexion à la base de données
	    try {
	        // tentative de connexion
	        con = DriverManager.getConnection(URL, LOGIN, PASS);

	        // préparation de l'instruction SQL
	        ps = con.prepareStatement("UPDATE BAIL SET duree = ? WHERE idBail = ?");
	        ps.setInt(1, nom);
	        ps.setInt(2, idLocataire);

	        // exécution de la requête
	        returnValue = ps.executeUpdate();

	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        // fermeture du preparedStatement et de la connexion
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}

	public int updateDateFin(int idBail, String dateFin) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // connexion à la base de données
    try {
        // tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE BAIL SET dateFin = ? WHERE idBail = ?");
        ps.setString(1, dateFin);
        ps.setInt(2, idBail);

        // exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

	public int updateMontantLoyer(int idBail, float montantLoyer) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // connexion à la base de données
    try {
        // tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE BAIL SET montantLoyer = ? WHERE idBail = ?");
        ps.setFloat(1, montantLoyer);
        ps.setInt(2, idBail);

        // exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

	public int updateCharges(int idBail, float charges) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // connexion à la base de données
    try {
        // tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE BAIL SET charges = ? WHERE idBail = ?");
        ps.setFloat(1, charges);
        ps.setInt(2, idBail);

        // exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

	public int updateMontantCaution(int idBail, float montantCaution) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE BAIL SET montantCaution = ? WHERE idBail = ?");
        ps.setFloat(1, montantCaution);
        ps.setInt(2, idBail);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

	public int updateFraisAgence(int idBail, float fraisAgence) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE BAIL SET fraisAgence = ? WHERE idBail = ?");
        ps.setFloat(1, fraisAgence);
        ps.setInt(2, idBail);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

	
	public int updateDateEcheance(int idBail, int dateEcheance) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE BAIL SET dateEcheance = ? WHERE idBail = ?");
        ps.setInt(1, dateEcheance);
        ps.setInt(2, idBail);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

public int updateFreqRevision(int idBail, int freqRevision) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE BAIL SET freqRevision = ? WHERE idBail = ?");
        ps.setInt(1, freqRevision);
        ps.setInt(2, idBail);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

	public int updateIdBailleur(int idBail, int newIdBailleur) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE BAIL SET idBailleur = ? WHERE idBail = ?");
        ps.setInt(1, newIdBailleur);
        ps.setInt(2, idBail);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

public int updateIdLocataire(int idBail, int newIdLocataire) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE BAIL SET idLocataire = ? WHERE idBail = ?");
        ps.setInt(1, newIdLocataire);
        ps.setInt(2, idBail);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}

public int updateIdGarant(int idBail, int newIdGarant) {
    Connection con = null;
    PreparedStatement ps = null;
    int returnValue = 0;

    // Connexion à la base de données
    try {
        // Tentative de connexion
        con = DriverManager.getConnection(URL, LOGIN, PASS);

        // Préparation de l'instruction SQL
        ps = con.prepareStatement("UPDATE BAIL SET idGarant = ? WHERE idBail = ?");
        ps.setInt(1, newIdGarant);
        ps.setInt(2, idBail);

        // Exécution de la requête
        returnValue = ps.executeUpdate();

    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        // Fermeture du preparedStatement et de la connexion
        try {
            if (ps != null) {
                ps.close();
            }
        } catch (Exception ignore) {
        }
        try {
            if (con != null) {
                con.close();
            }
        } catch (Exception ignore) {
        }
    }
    return returnValue;
}


	/**
	 * Permet de supprimer un bien par identifiant dans la table BIEN.
	 * Le mode est auto-commit par defaut : chaque suppression est validee
	 * 
	 * @param idBien l'identifiant du bien à supprimer
	 * @return retourne le nombre de lignes supprimees dans la table
	 */
	public int deleteBien(int idBien) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;

		// connexion a la base de donnees
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// preparation de l'instruction SQL, le ? represente la valeur de l'ID
			// a communiquer dans la suppression.
			// le getter permet de recuperer la valeur de l'ID du bien
			ps = con.prepareStatement("DELETE FROM BIEN WHERE idBien = ?");
			ps.setInt(1, idBien);

			// Execution de la requete
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	/**
	 * Permet de recuperer un bien a partir de sa reference
	 * 
	 * @param idBien l'identifiant du bien a recuperer
	 * @return le bien trouve; null si aucun bien ne correspond a cet identifiant
	 */
	
	
	public Bien getBail(int idBien) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Bien returnValue = null;

		// connexion a la base de donnees
		try {

			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM BIEN WHERE idBien = ?");
			ps.setInt(1, idBien);

			// on execute la requete
			// rs contient un pointeur situe juste avant la premiere ligne retournee
			rs = ps.executeQuery();
			// passe a la premiere (et unique) ligne retournee
			if (rs.next()) {
				returnValue = new Bien(rs.getInt("idBien"), rs.getString("typeBien"), 
									   rs.getFloat("surfaceBien"), rs.getInt("codePostal"),
									   rs.getBoolean("isMaisonIndividuelle"), rs.getBoolean("isAppartement"),
									   rs.getInt("nombreChambre"), rs.getInt("anneeConstruction"),
									   rs.getInt("arrondissement"), rs.getString("ville"),
									   rs.getInt("numAppartement"), rs.getInt("numEtage"),
									   rs.getInt("numRue"), rs.getString("typeRue"),
									   rs.getString("nomRue"), rs.getString("nomResidence"),
									   rs.getBoolean("isChauffageIndividuel"), rs.getString("typeChauffage"),
							           rs.getBoolean("isJardin"), rs.getFloat("surfaceJardin"),
								   	   rs.getBoolean("isMeuble"), rs.getBoolean("isTerrain"),
									   rs.getFloat("surfaceTerrain"), rs.getBoolean("isEscalier"),
									   rs.getBoolean("isCave"), rs.getBoolean("isSousSol"),
									   rs.getBoolean("isCour"), rs.getFloat("surfaceCour"),
									   rs.getBoolean("isBalcon"), rs.getFloat("surfaceBalcon"),
									   rs.getBoolean("isTerrasse"), rs.getFloat("surfaceTerrasse"),
									   rs.getString("descriptionMeuble"));
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du ResultSet, du PreparedStatement et de la Connexion
			try {
				if (rs != null) {
					rs.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}

	public String[] getBailPartiel(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String[] returnValue = new String[2]; // Pour stocker id et type

	    // Connexion à la base de données
	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT idBien, typeBien, surfaceBien, adresse, ville FROM BIEN WHERE idBien = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue[0] = rs.getString("idBien"); // Récupération de id
	            returnValue[1] = rs.getString("typeBien"); // Récupération de type
	            returnValue[2] = rs.getString("surfaceBien"); // Récupération de type
	            returnValue[3] = rs.getString("adresse"); // Récupération de type
	            returnValue[4] = rs.getString("ville"); // Récupération de type


	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public String getBailId(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT idBail FROM BAIL WHERE idBail = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("idBail"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	
	public String getLocataireId(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT idLocataire FROM BAIL WHERE idBail = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("idLocataire"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public String getBailleurId(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT idBailleur FROM BAIL WHERE idBail = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("idBailleur"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}
	
	public String getBailType(int idBien) {
	    Connection con = null;
	    PreparedStatement ps = null;
	    ResultSet rs = null;
	    String returnValue = null; // Pour stocker l'ID

	    try {
	        con = DriverManager.getConnection(URL, LOGIN, PASS);
	        ps = con.prepareStatement("SELECT typeBail FROM BAIL WHERE idBail = ?");
	        ps.setInt(1, idBien);

	        // Exécution de la requête
	        rs = ps.executeQuery();
	        
	        // Si une ligne est retournée
	        if (rs.next()) {
	            returnValue = rs.getString("typeBail"); // Récupération de l'ID
	        }
	    } catch (Exception ee) {
	        ee.printStackTrace();
	    } finally {
	        // Fermeture des ressources
	        try {
	            if (rs != null) {
	                rs.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (ps != null) {
	                ps.close();
	            }
	        } catch (Exception ignore) {
	        }
	        try {
	            if (con != null) {
	                con.close();
	            }
	        } catch (Exception ignore) {
	        }
	    }
	    return returnValue;
	}

	
	
	
	
	/**
	 * Permet de recuperer tous les baux stockes dans la table BAIL
	 * 
	 * @return une ArrayList de Bail
	 */	
	public ArrayList<Bail> getList() {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Bail> returnValue = new ArrayList<Bail>();

		// connexion a la base de donnees
		try {
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM BAIL ORDER BY idBail");

			// on execute la requete
			rs = ps.executeQuery();
			// on parcourt les lignes du resultat
			while (rs.next()) {
				returnValue.add(new Bail(rs.getInt("idBail"), rs.getInt("idBailleur"), 
										 rs.getInt("idLocataire"), rs.getInt("idGarant"),
										 rs.getInt("duree"), rs.getString("typeBail"),
										 rs.getString("datePriseEffet"), rs.getString("dateFin"),
										 rs.getInt("dateEcheance"), rs.getFloat("montantLoyer"),
										 rs.getFloat("fraisAgence"), rs.getFloat("charges"),
										 rs.getFloat("montantCaution"), rs.getInt("freqRevision")));
			}
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du rs, du preparedStatement et de la connexion
			try {
				if (rs != null)
					rs.close();
			} catch (Exception ignore) {
			}
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
}