package model;
import java.util.*;

/**
 * Classe representant un Echeance
 * 
 * @author DAOUDA Ilyas + DIOUBATE Nicolas
 * @version 1.0
 */
public class Echeance {
	
	/**
	 * id du Echeance
	 */
	private int idEcheance;
	
	/**
	 * id du Garant
	 */
	private int idBail;
	
	/**
	 * id du Echeanceleur
	 */
	//private int id;
	
	/**
	 * id du Locataire
	 */
	private int idLocataire;
	
	/**
	 * montantRetard du Echeance (en mois)
	 */
	private float montantRetard;
	
	/**
	 * commentaire du Echeance
	 */
	private String commentaire;
	
	/**
	 * Date de debut du Echeance
	 */
	
	/**
	 * Date de fin du Echeance
	 */
	private Date dateFin;
	
	/**
	 * Montant du loyer
	 */
	private float montantLoyer;
	
	
	private String statutPaiement;
	
	/**
	 * Frais d'agence
	 */
	private float historique;
	
	/**
	 * Charges du Echeance
	 */
	private float charges;
	
	/**
	 * Montant de la caution
	 */
	private float penaliteRetard;
	
	/**
	 * Date d'échéance
	 */
	private String dateEcheance;
	
	/**
	 * Frequence de revision du loyer
	 */
	private int frequenceRevisionLoyer;
	
	
	/**
	 * Constructeur de la classe Echeance
	 * 
	 * @param montantRetard : montantRetard quelconque
	 * @param commentaire : commentaire quelconque
	 * @param dateEcheance : date de debut quelconque
	 * @param dateFin : date de fin quelconque 
	 * @param montantLoyer : montant quelconque
	 * @param historique : valeur quelconque
	 * @param charges : valeur quelconque
	 * @param penaliteRetard : valeur quelconque
	 * @param frequenceRevisionLoyer : frequence quelconque
	 * @param presenceGarant : valeur true si la Echeance a un garant
	 * @param garant : un garant 
	 */
	public Echeance(int idEcheance, String dateEcheance, String statutPaiement, float historique, float montantLoyer, 
            float montantRetard, float penaliteRetard, String commentaire, int idLocataire, int idBail) {
this.idEcheance = idEcheance;
this.dateEcheance = dateEcheance;
this.statutPaiement = statutPaiement;
this.historique = historique;
this.montantLoyer = montantLoyer;
this.montantRetard = montantRetard;
this.penaliteRetard = penaliteRetard;
this.commentaire = commentaire;
this.idLocataire = idLocataire;
this.idBail = idBail;
}

	
	/**
	 * getter de l'attribut idEcheance
	 * 
	 * @return l'attribut idEcheance
	 */
	public int getIdEcheance( ) {
		return idEcheance;
	}
	
	/**
	 * getter de l'attribut idGarant
	 * 
	 * @return l'attribut idGarant
	 */
	
	
	/**
	 * getter de l'attribut idEcheanceleur
	 * 
	 * @return l'attribut iEcheanceleur
	 */
	public int getIdBail( ) {
		return idBail;
	}
	
	/**
	 * getter de l'attribut idLocataire
	 * 
	 * @return l'attribut idLocataire
	 */
	public int getIdLocataire( ) {
		return idLocataire;
	}
	
	
	/**
	 * getter de l'attribut montantRetard
	 * 
	 * @return l'attribut montantRetard
	 */
	public float getMontantRetard( ) {
		return montantRetard;
	}
	
	/**
	 * getter de l'attribut commentaire
	 * 
	 * @return l'attribut commentaire
	 */
	public String getCommentaire( ) {
		return commentaire;
	}
	
	/**
	 * getter de l'attribut dateEcheance
	 * 
	 * @return l'attribut dateEcheance
	 */
	public String getDateEcheance( ) {
		return dateEcheance;
	}
	
	
	public String getStatutPaiement( ) {
		return statutPaiement;
	}
	/**
	 * getter de l'attribut dateFin
	 * 
	 * @return l'attribut dateFin
	 */
	
	/**
	 * getter de l'attribut dateEcheance
	 * 
	 * @return l'attribut dateEcheance
	 */
	
	
	/**
	 * getter de l'attribut montantLoyer
	 * 
	 * @return l'attribut montantLoyer
	 */
	public float getMontantLoyer( ) {
		return montantLoyer;
	}
	
	/**
	 * getter de l'attribut penaliteRetard
	 * 
	 * @return l'attribut penaliteRetard
	 */
	public float getPenaliteRetard( ) {
		return penaliteRetard;
	}
	
	/**
	 * getter de l'attribut historique
	 * 
	 * @return l'attribut historique
	 */
	public float getHistorique( ) {
		return historique;
	}
	
	/**
	 * getter de l'attribut charges
	 * 
	 * @return l'attribut charges
	 */
	
	
	/**
	 * getter de l'attribut frequenceRevisionLoyer
	 * 
	 * @return l'attribut frequenceRevisionLoyer
	 */
	
}