package dao;

public class BailDAO {

}
