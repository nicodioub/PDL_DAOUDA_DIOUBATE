package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainInterfaceLocataire extends JFrame {
	
	private JPanel jlBackground;
	private JLabel jlColor;
	private JButton ajoutLocataire;
	private JButton Bien;
	private JButton Locataire;

	private Container container;

	private AddProperty window;
	
	private boolean addPropertyButton = false;


	public MainInterfaceLocataire (String title, int width, int height  ) {
		
		this.setTitle(title);
		this.setSize(width, height);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		int buttonWidth = 100; // Largeur du JButton
        int buttonHeight = 30; // Hauteur du JButton
        
        

		jlBackground = new JPanel();
		this.setContentPane(jlBackground);
		Bien = new JButton("Bien");
		Locataire = new JButton("Locataire");
		ajoutLocataire= new JButton("+ Ajouter un locataire");
		container = this.getContentPane();
		
		String[] columnNames = {"id", "prenom","nom","adresse","email", "telephone" , "societe"};
		
		Object[][] data = {
				
		};
		JTable table = new JTable(data, columnNames);
		
	    //table.setBackground(Color.BLACK); // Change to desired color

		
		JScrollPane scrollPane = new JScrollPane(table);
        
		 //scrollPane.getViewport().setBackground(Color.BLACK); // Change to desired color

	        
		container.setLayout(null); // Définir le layout sur null pour permettre le positionnement absolu
        
		scrollPane.setBounds(0, 100, 1400, 600); // Adjust bounds as needed
        ajoutLocataire.setBounds(1150, 50, 200, buttonHeight);
	    Bien.setBounds(500,50  , 100, 30);
	    Locataire.setBounds(600,50,100,30);

	    
        container.add(ajoutLocataire);
        container.add(Bien);
        container.add(Locataire);
        container.add(scrollPane);
		jlBackground.setBackground(Color.BLACK);

		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		ajoutLocataire.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	addPropertyButton = true;
		    	AjoutLocataire Window5 = new AjoutLocataire("Logiciel de gestion DD", 1400,800);
		    	Window5.setVisible(true);
		        dispose(); // Ferme l'interface 2
		    }
		});
		
		Bien.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
			    	addPropertyButton = true;
			    	MainInterface Window1 = new MainInterface("Logiciel de gestion DD", 1400,800);
			    	Window1.setVisible(true);
			        dispose(); // Ferme l'interface 2
			    }
			
		});
		

	}
	
	/**
	 * Permet de verifier si l'utilisateur a clique sur 'Ajouter bail'
	 * 
	 * @return l'attribut addPropertyButton
	 */
	public boolean addPropertyClicked() {
		return addPropertyButton;
	}


}
