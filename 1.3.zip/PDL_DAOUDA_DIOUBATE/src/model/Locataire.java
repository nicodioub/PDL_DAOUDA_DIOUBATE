package model;
/**
 * Classe representant un Locataire (extension de personne)
 * 
 * @author DAOUDA Ilyas + DIOUBATE Nicolas
 * @version 1.0
 */
public class Locataire extends Personne{

	/**
	 * Permet de savoir si le locataire est une societe ou non
	 */
	private String societe;
	
	
	private int id; 
	
	/**
	 * Raison sociale d'un locataire (si c'est une entreprise)
	 */
	private String raisonSociale;
	
	private String adresse;
	
	/**
	 * Bail auquel le locataire est associe
	 */
	
	private int idBail;
	
	private Bail bail;
	
	/**
	 * Bien immobilier auquel le locataire est associé
	 */
	private Bien bienImmobilier;
	
	private int idBien;
	/**
	 * Constructeur de la classe Bailleur
	 * 
	 * @param unNom : nom quelconque
	 * @param unPrenom : prenom quelconque
	 * @param unEmail : email quelconque
	 * @param unNumero : numero quelconque
	 * @param societe : valeur true si le locataire est une societe 
	 * @param raisonSociale : raison sociale quelconque
	 * @param bail : un bail
	 * @param bienImmobilier : un bien immobilier
	 */
	public Locataire (int unId, String unNom, String unPrenom, String uneAdresse, String unEmail, String unNumero, String societe, String raisonSociale,
			int idbail, int idBien)
	{
		super(unNom, unPrenom, unEmail, unNumero);
		this.societe = societe;
		this.raisonSociale = raisonSociale;
		idBail = idbail;
		idBien  = idBien;
		id = unId;
		adresse = uneAdresse ; 
	}
	
	
	/**
	 * getter de l'attribut societe
	 * 
	 * @return l'attribut societe
	 */
	public String getSociete() {
		return societe;
	}


	/**
	 * getter de l'attribut raisonSociale
	 * 
	 * @return l'attribut raisonSociale
	 */
	public String getRaisonSociale() {
		return raisonSociale;
	}
	
	public String getAdresse() {
		return adresse;
	}
	
	public void setAdresse(String adresse2) {
		adresse = adresse2;
	}

	
	public int getIdLocataire() {
		return id;
	}
	
	public void setIdLocataire(int id2) {
		id = id2;
	}

	/**
	 * setter de l'attribut raisonSociale
	 * 
	 * @param raisonSociale : nouvelle raison sociale
	 */
	public void setRaisonSociale(String raisonSociale) {
		this.raisonSociale = raisonSociale;
	}
	
	public int getIdBien() {
		return idBien;
	}
	
	public int getIdBail() {
		return idBail;
	}
	/**
	 * affiche les informations sur un locataire (personne)
	 */
	@Override
	public void display() {
		super.display();
		System.out.print("\nSociete : ");
		if (societe == true) {
			System.out.print("Oui");
			System.out.print("\nRaison sociale : " + raisonSociale);
		}
		else
			System.out.print("Non");
	}
}
