package dao;

public class AppartementDAO {

}
