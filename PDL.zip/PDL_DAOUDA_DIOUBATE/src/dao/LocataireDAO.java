package dao;

public class LocataireDAO {

}
